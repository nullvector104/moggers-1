/**
 * Tactical disaster response types for the
 * Upper Alaknanda – Dhauliganga Flash Flood Early Warning System (EWS)
 * Phase 2 Command & Control (C2) Dashboard.
 *
 * All monetary / scientific units follow WMO / NDMA / ISRO DMSP conventions.
 */

/** Hydro-meteorological scenario driving the simulation engine. */
export type ScenarioKey = 'dry' | 'monsoon' | 'cloudburst';

/** CAP v1.2 severity tiers mapped to NDMA colour codes. */
export type AlertSeverity = 'GREEN' | 'YELLOW' | 'ORANGE' | 'RED';

/** Classification of telemetry nodes deployed across the catchment. */
export type SensorType =
  | 'rainfall'
  | 'stage'
  | 'discharge'
  | 'aws' // Automatic Weather Station
  | 'outpost'
  | 'barrage';

/** Operational health of a sensor / relay node. */
export type NodeStatus = 'active' | 'degraded' | 'offline';

/** Telemetry time-series sample (one per 10-minute interval). */
export interface TelemetryPoint {
  /** ISO-8601 timestamp (UTC) of the sample. */
  iso: string;
  /** Minutes relative to scenario T0 (negative = past, positive = projection). */
  t: number;
  /** Rainfall intensity in mm/hr. */
  rainfall: number;
  /** Dynamic Flash Flood Guidance threshold in mm/hr (varies w/ soil saturation). */
  ffg: number;
  /** River discharge Q in m³/s. */
  discharge: number;
  /** Gauge / stage height in metres above MSL. */
  stage: number;
  /** Critical bankfull stage at the gauging station (m). */
  bankfull: number;
  /** True when this point is a forecast projection (right of T0 marker). */
  projected: boolean;
}

/** A geolocated telemetry / relay node on the catchment map. */
export interface CatchmentNode {
  id: string;
  label: string;
  /** WGS-84 latitude (decimal degrees, North positive). */
  lat: number;
  /** WGS-84 longitude (decimal degrees, East positive). */
  lon: number;
  type: SensorType;
  status: NodeStatus;
  /** Sub-catchment the node belongs to. */
  catchment: 'upper' | 'mid' | 'lower';
  /** Optional live reading shown on the map tooltip. */
  reading?: string;
}

/** Sub-catchment descriptor used by the hazard map + cascade panel. */
export interface SubCatchment {
  id: 'upper' | 'mid' | 'lower';
  name: string;
  areaKm2: number;
  meanSlopeDeg: number;
  forestCoverPct: number;
  stageM: number;
  bankfullM: number;
  dischargeQ: number;
  alert: AlertSeverity;
}

/** CAP v1.2 compliant emergency alert payload (OASIS standard). */
export interface CAPAlert {
  identifier: string;
  sender: string;
  sent: string; // ISO-8601 UTC
  status: 'Actual' | 'Test' | 'Exercise' | 'Draft';
  msgType: 'Alert' | 'Update' | 'Cancel' | 'Ack' | 'Error';
  scope: 'Public' | 'Restricted' | 'Private';
  info: {
    event: string;
    urgency: 'Immediate' | 'Expected' | 'Future' | 'Past' | 'Unknown';
    severity: 'Extreme' | 'Severe' | 'Moderate' | 'Minor' | 'Unknown';
    certainty: 'Observed' | 'Likely' | 'Possible' | 'Unlikely' | 'Unknown';
    onset: string;
    expires: string;
    headline: string;
    description: string;
    instruction: string;
    area: {
      areaDesc: string;
      polygon: string; // "lat,lon lat,lon ..."
      geocode: string;
    };
  };
}

/** Multi-channel broadcast checklist item for the dispatch modal. */
export interface BroadcastChannel {
  id: string;
  label: string;
  detail: string;
  enabled: boolean;
}

/** Live uplink channel shown in the telemetry health bar. */
export interface UplinkChannel {
  id: string;
  label: string;
  detail: string;
  status: 'active' | 'connected' | 'degraded' | 'offline';
  signalPct: number;
}

/** Slider / gauge control bound to the simulation store. */
export interface SliderControl {
  id: string;
  label: string;
  unit: string;
  min: number;
  max: number;
  step: number;
  value: number;
  hint: string;
}

/** Static configuration for the three scenarios. */
export interface ScenarioConfig {
  key: ScenarioKey;
  label: string;
  shortLabel: string;
  description: string;
  severity: AlertSeverity;
  /** Base rainfall intensity (mm/hr). */
  baseRainfall: number;
  /** Peak rainfall intensity during scenario (mm/hr). */
  peakRainfall: number;
  /** Antecedent moisture index 0–1. */
  antecedentMoisture: number;
  /** Snowmelt contribution (m³/s). */
  snowmeltContribution: number;
  /** Minutes until the projected surge arrives at Vishnuprayag (≤0 = no surge). */
  surgeArrivalMin: number;
  /** Accent colour used across the UI for this scenario. */
  accent: string;
}

/** Mapping of scenario key -> scenario configuration. */
export const SCENARIO_CONFIGS: Record<ScenarioKey, ScenarioConfig> = {
  dry: {
    key: 'dry',
    label: 'Dry Normal',
    shortLabel: 'DRY',
    description:
      'Pre-monsoon baseflow. Snowmelt-dominated regime, minimal convective activity, FFG well above observed rainfall.',
    severity: 'GREEN',
    baseRainfall: 1.2,
    peakRainfall: 2.8,
    antecedentMoisture: 0.18,
    snowmeltContribution: 12,
    surgeArrivalMin: 0,
    accent: '#22c55e',
  },
  monsoon: {
    key: 'monsoon',
    label: 'Active Monsoon',
    shortLabel: 'MON',
    description:
      'Sustained south-westerly monsoon trough. Soil saturation rising, FFG threshold dropping, isolated heavy spells expected over the Upper catchment.',
    severity: 'YELLOW',
    baseRainfall: 8.5,
    peakRainfall: 28,
    antecedentMoisture: 0.62,
    snowmeltContribution: 22,
    surgeArrivalMin: 0,
    accent: '#eab308',
  },
  cloudburst: {
    key: 'cloudburst',
    label: 'Critical Cloudburst',
    shortLabel: 'CB',
    description:
      'Catastrophic convective burst (>100 mm/hr) anchored over the Upper Dhauliganga. Exponential stage surge propagating downstream — imminent overtopping at Vishnuprayag.',
    severity: 'RED',
    baseRainfall: 36,
    peakRainfall: 142,
    antecedentMoisture: 0.91,
    snowmeltContribution: 48,
    surgeArrivalMin: 26,
    accent: '#ef4444',
  },
};

/** Convenience accessor: scenario -> NDMA colour hex. */
export const SEVERITY_COLOURS: Record<AlertSeverity, string> = {
  GREEN: '#22c55e',
  YELLOW: '#eab308',
  ORANGE: '#f97316',
  RED: '#ef4444',
};

/** Convenience accessor: scenario -> NDMA description. */
export const SEVERITY_LABELS: Record<AlertSeverity, string> = {
  GREEN: 'NORMAL',
  YELLOW: 'ADVISORY',
  ORANGE: 'PREPAREDNESS',
  RED: 'CATACLYSMIC',
};
