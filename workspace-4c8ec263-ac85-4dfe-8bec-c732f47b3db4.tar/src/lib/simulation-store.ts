'use client';

import { create } from 'zustand';
import {
  SCENARIO_CONFIGS,
  type AlertSeverity,
  type ScenarioKey,
  type TelemetryPoint,
} from './tactical-types';

/**
 * Simulation store: single source of truth for the C2 dashboard.
 * Drives scenario state, derived hydro-physical gauges, telemetry history,
 * surge countdown, audio mute toggle, and the per-second wall clock.
 */

interface SimulationState {
  /** Active scenario key (toggled by the operator). */
  scenario: ScenarioKey;
  /** Live wall-clock tick, advanced every second by SimulationClock. */
  tick: number;
  /** Live rainfall intensity (mm/hr) — adjustable via slider. */
  rainfallIntensity: number;
  /** Live antecedent soil moisture (0–1). */
  antecedentMoisture: number;
  /** Snowmelt contribution to baseflow (m³/s). */
  snowmeltContribution: number;
  /** Dynamic Flash Flood Guidance threshold (mm/hr). */
  ffgThreshold: number;
  /** Live river discharge Q at Vishnuprayag (m³/s). */
  dischargeQ: number;
  /** Live gauge / stage height at Vishnuprayag (m). */
  stageH: number;
  /** Critical bankfull stage at Vishnuprayag (m). */
  bankfullStage: number;
  /** Minutes until surge arrival (≤0 = no active surge). */
  surgeArrivalMin: number;
  /** True when the evacuation siren is muted by the operator. */
  audioMuted: boolean;
  /** True while the CAP dispatch modal is open. */
  dispatchOpen: boolean;
  /** Cached 8-hour telemetry window (6 h past + 2 h projection). */
  history: TelemetryPoint[];

  // ---- actions ----
  setScenario: (s: ScenarioKey) => void;
  setRainfall: (v: number) => void;
  setMoisture: (v: number) => void;
  setSnowmelt: (v: number) => void;
  toggleMute: () => void;
  setDispatchOpen: (open: boolean) => void;
  advanceTick: () => void;
  regenerateHistory: () => void;
}

/** 8-hour window of 10-minute samples => 48 points. */
const HISTORY_LENGTH = 48;
const PAST_LENGTH = 36; // 6 hours past
const SAMPLE_MIN = 10;

/**
 * Generate a deterministic-but-noisy telemetry window for the active scenario.
 * Past points reflect observed conditions; future points reflect projections,
 * with an exponential surge when scenario = cloudburst.
 */
function generateHistory(
  scenario: ScenarioKey,
  rainfallIntensity: number,
  antecedentMoisture: number,
  snowmelt: number,
  surgeArrival: number,
  stageH: number,
  dischargeQ: number,
  bankfull: number,
): TelemetryPoint[] {
  const cfg = SCENARIO_CONFIGS[scenario];
  const now = Date.now();
  const points: TelemetryPoint[] = [];

  for (let i = 0; i < HISTORY_LENGTH; i++) {
    const t = (i - PAST_LENGTH) * SAMPLE_MIN; // negative = past
    const projected = t > 0;
    const iso = new Date(now + t * 60_000).toISOString();

    // Deterministic pseudo-noise (no Math.random so SSR matches CSR).
    const noise = Math.sin(i * 1.7) * 0.5 + Math.cos(i * 0.9) * 0.3;
    const trend = i / HISTORY_LENGTH;

    // Rainfall: base ramp toward current intensity, with cloudburst spike in projection.
    let rainfall: number;
    if (projected && scenario === 'cloudburst') {
      // exponential burst peaking near surge arrival
      const tau = Math.max(1, surgeArrival);
      const k = Math.max(0, (tau - t)) / tau;
      rainfall = cfg.peakRainfall * Math.exp(-2 * k) + noise * 4;
    } else {
      rainfall = cfg.baseRainfall + trend * (rainfallIntensity - cfg.baseRainfall) + noise;
    }
    rainfall = Math.max(0, rainfall);

    // FFG drops as soil saturates.
    const ffg = Math.max(
      8,
      65 - antecedentMoisture * 38 - (scenario === 'cloudburst' ? trend * 18 : 0),
    );

    // Discharge: baseflow + runoff response.
    const baseflow = snowmelt + 8 + antecedentMoisture * 22;
    let discharge: number;
    if (projected && scenario === 'cloudburst') {
      // exponential surge in Q
      const tau = Math.max(1, surgeArrival);
      const k = Math.max(0, (tau - t)) / tau;
      discharge = baseflow + 1450 * Math.exp(-2.6 * k) + noise * 6;
    } else {
      discharge = baseflow + trend * (dischargeQ - baseflow) + noise * 3;
    }
    discharge = Math.max(2, discharge);

    // Stage: rating curve h ~ k * sqrt(Q) (simplified Manning-based relation).
    const stageBase = 1.4 + 0.16 * Math.sqrt(discharge);
    let stage = stageBase + noise * 0.05;
    if (projected && scenario === 'cloudburst') {
      const tau = Math.max(1, surgeArrival);
      const k = Math.max(0, (tau - t)) / tau;
      stage += 4.2 * Math.exp(-2.4 * k);
    }
    stage = Math.max(0.6, stage);

    points.push({
      iso,
      t,
      rainfall: round(rainfall, 1),
      ffg: round(ffg, 1),
      discharge: round(discharge, 0),
      stage: round(stage, 2),
      bankfull,
      projected,
    });
  }

  return points;
}

function round(v: number, digits: number): number {
  const m = 10 ** digits;
  return Math.round(v * m) / m;
}

/** Derive live hydro gauges from the scenario + slider state. */
function deriveGauges(
  scenario: ScenarioKey,
  rainfall: number,
  moisture: number,
  snowmelt: number,
): { dischargeQ: number; stageH: number; bankfull: number; ffg: number; surgeArrivalMin: number } {
  const cfg = SCENARIO_CONFIGS[scenario];
  const baseflow = snowmelt + 8 + moisture * 22;

  let dischargeQ: number;
  let stageH: number;
  let ffg: number;
  let surgeArrivalMin = cfg.surgeArrivalMin;

  if (scenario === 'cloudburst') {
    dischargeQ = baseflow + 1450;
    stageH = 1.4 + 0.16 * Math.sqrt(dischargeQ) + 4.2;
    ffg = Math.max(8, 65 - moisture * 38 - 18);
  } else if (scenario === 'monsoon') {
    dischargeQ = baseflow + 280 + rainfall * 4;
    stageH = 1.4 + 0.16 * Math.sqrt(dischargeQ) + 0.4;
    ffg = Math.max(12, 55 - moisture * 28);
    surgeArrivalMin = 0;
  } else {
    dischargeQ = baseflow + rainfall * 1.5;
    stageH = 1.4 + 0.16 * Math.sqrt(dischargeQ);
    ffg = Math.max(28, 70 - moisture * 18);
    surgeArrivalMin = 0;
  }

  return {
    dischargeQ: round(dischargeQ, 0),
    stageH: round(stageH, 2),
    bankfull: 4.6, // Critical bankfull at Vishnuprayag gauge
    ffg: round(ffg, 1),
    surgeArrivalMin,
  };
}

export const useSimulation = create<SimulationState>((set, get) => ({
  scenario: 'monsoon',
  tick: 0,
  rainfallIntensity: SCENARIO_CONFIGS.monsoon.baseRainfall,
  antecedentMoisture: SCENARIO_CONFIGS.monsoon.antecedentMoisture,
  snowmeltContribution: SCENARIO_CONFIGS.monsoon.snowmeltContribution,
  ffgThreshold: 32,
  dischargeQ: 0,
  stageH: 0,
  bankfullStage: 4.6,
  surgeArrivalMin: 0,
  audioMuted: true, // muted by default — operator must opt-in to siren
  dispatchOpen: false,
  history: [],

  setScenario: (s) => {
    const cfg = SCENARIO_CONFIGS[s];
    const g = deriveGauges(s, cfg.baseRainfall, cfg.antecedentMoisture, cfg.snowmeltContribution);
    const history = generateHistory(
      s,
      cfg.baseRainfall,
      cfg.antecedentMoisture,
      cfg.snowmeltContribution,
      cfg.surgeArrivalMin,
      g.stageH,
      g.dischargeQ,
      g.bankfull,
    );
    set({
      scenario: s,
      rainfallIntensity: cfg.baseRainfall,
      antecedentMoisture: cfg.antecedentMoisture,
      snowmeltContribution: cfg.snowmeltContribution,
      ffgThreshold: g.ffg,
      dischargeQ: g.dischargeQ,
      stageH: g.stageH,
      bankfullStage: g.bankfull,
      surgeArrivalMin: g.surgeArrivalMin,
      history,
    });
  },

  setRainfall: (v) => {
    const st = get();
    const g = deriveGauges(st.scenario, v, st.antecedentMoisture, st.snowmeltContribution);
    set({
      rainfallIntensity: v,
      ffgThreshold: g.ffg,
      dischargeQ: g.dischargeQ,
      stageH: g.stageH,
    });
    get().regenerateHistory();
  },

  setMoisture: (v) => {
    const st = get();
    const g = deriveGauges(st.scenario, st.rainfallIntensity, v, st.snowmeltContribution);
    set({
      antecedentMoisture: v,
      ffgThreshold: g.ffg,
      dischargeQ: g.dischargeQ,
      stageH: g.stageH,
    });
    get().regenerateHistory();
  },

  setSnowmelt: (v) => {
    const st = get();
    const g = deriveGauges(st.scenario, st.rainfallIntensity, st.antecedentMoisture, v);
    set({
      snowmeltContribution: v,
      dischargeQ: g.dischargeQ,
      stageH: g.stageH,
    });
    get().regenerateHistory();
  },

  toggleMute: () => set((s) => ({ audioMuted: !s.audioMuted })),
  setDispatchOpen: (open) => set({ dispatchOpen: open }),

  advanceTick: () => {
    const st = get();
    // For cloudburst, count down the surge arrival each second (in minutes).
    let surgeArrivalMin = st.surgeArrivalMin;
    if (surgeArrivalMin > 0) {
      const next = surgeArrivalMin - 1 / 60;
      surgeArrivalMin = next <= 0 ? 0 : next;
    }
    set({ tick: st.tick + 1, surgeArrivalMin });
  },

  regenerateHistory: () => {
    const st = get();
    const history = generateHistory(
      st.scenario,
      st.rainfallIntensity,
      st.antecedentMoisture,
      st.snowmeltContribution,
      st.surgeArrivalMin,
      st.stageH,
      st.dischargeQ,
      st.bankfullStage,
    );
    set({ history });
  },
}));

/** Convenience selector: severity derived from the active scenario. */
export function useSeverity(): AlertSeverity {
  return SCENARIO_CONFIGS[useSimulation((s) => s.scenario)].severity;
}
