import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ALAKNANDA-DHAULIGANGA EWS // C2 TACTICAL DASHBOARD",
  description:
    "Phase 2 Command & Control situational dashboard for the Upper Alaknanda–Dhauliganga Flash Flood Early Warning System. Operated by NDRF-08-BN (Chamoli) in coordination with NDMA, ISRO DMSP, and WMO CAP v1.2 broadcast channels.",
  keywords: [
    "Alaknanda",
    "Dhauliganga",
    "Chamoli",
    "Flash Flood",
    "NDRF",
    "NDMA",
    "ISRO DMSP",
    "CAP v1.2",
    "Hydrology",
    "Tactical Dashboard",
    "Early Warning System",
  ],
  authors: [{ name: "NDRF-08-BN Chamoli // ISRO DMSP Cell" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Alaknanda-Dhauliganga EWS // C2 Tactical Dashboard",
    description:
      "Real-time flash flood early warning situational awareness for the Upper Alaknanda catchment.",
    url: "https://chat.z.ai",
    siteName: "Alaknanda-Dhauliganga EWS",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Alaknanda-Dhauliganga EWS // C2 Tactical Dashboard",
    description:
      "Real-time flash flood early warning situational awareness for the Upper Alaknanda catchment.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
