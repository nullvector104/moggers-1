'use client';

import {
  Activity,
  Building2,
  CloudRain,
  Radio,
  ShieldAlert,
  Satellite,
} from 'lucide-react';
import { SimulationClock } from '@/components/tactical/SimulationClock';
import { TacticalAlertBanner } from '@/components/tactical/TacticalAlertBanner';
import { CatchmentHazardMap } from '@/components/tactical/CatchmentHazardMap';
import { CascadeSimulationPanel } from '@/components/tactical/CascadeSimulationPanel';
import { CatchmentTelemetryCharts } from '@/components/tactical/CatchmentTelemetryCharts';
import { HydroGauges } from '@/components/tactical/HydroGauges';
import {
  DisasterDispatchButton,
  DisasterDispatchModal,
} from '@/components/tactical/DisasterDispatchModal';
import { TelemetryHealthBar } from '@/components/tactical/TelemetryHealthBar';
import { useSimulation } from '@/lib/simulation-store';
import { SCENARIO_CONFIGS } from '@/lib/tactical-types';

/**
 * C2 Tactical Dashboard — Upper Alaknanda-Dhauliganga EWS Phase 2
 * ------------------------------------------------------------------
 * Desktop layout: left 55% hazard map + cascade; right 45% sliders,
 * gauges, charts. Banner + dispatch console overlay the top, with a
 * telemetry-health footer pinned to the viewport bottom.
 */
export default function Home() {
  const scenario = useSimulation((s) => s.scenario);
  const cfg = SCENARIO_CONFIGS[scenario];

  return (
    <div className="flex min-h-screen flex-col bg-slate-950 text-slate-100">
      <SimulationClock />

      {/* Top command ribbon */}
      <header className="border-b border-slate-800 bg-slate-950/95 backdrop-blur">
        <div className="mx-auto flex max-w-[1800px] flex-col gap-2 px-4 py-2.5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded border border-sky-700/50 bg-sky-950/60">
              <Satellite className="h-5 w-5 text-sky-400" />
            </div>
            <div>
              <h1 className="font-mono-tactical text-sm font-bold uppercase tracking-[0.18em] text-slate-100">
                Alaknanda-Dhauliganga EWS // C2 Tactical Dashboard
              </h1>
              <p className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-500">
                NDRF-08-BN · Chamoli · Phase 2 · ISRO DMSP / NDMA / WMO CAP v1.2
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <StatusChip icon={<Building2 className="h-3 w-3" />} label="DC Office" value="Chamoli" />
            <StatusChip icon={<Radio className="h-3 w-3" />} label="Net" value="SATCOM" tone="green" />
            <StatusChip icon={<CloudRain className="h-3 w-3" />} label="Scenario" value={cfg.shortLabel} tone={cfg.accent} />
            <StatusChip icon={<Activity className="h-3 w-3" />} label="EWS Build" value="v2.4.0" />
            <DisasterDispatchButton />
          </div>
        </div>
      </header>

      {/* Tactical alert banner */}
      <div className="mx-auto w-full max-w-[1800px] px-3 pt-3">
        <TacticalAlertBanner />
      </div>

      {/* Main grid: 55 / 45 split */}
      <main className="mx-auto grid w-full max-w-[1800px] flex-1 grid-cols-1 gap-3 p-3 lg:grid-cols-[55fr_45fr]">
        {/* LEFT 55% — Hazard map + cascade summary */}
        <div className="flex flex-col gap-3">
          <div className="min-h-[560px] flex-1">
            <CatchmentHazardMap />
          </div>
          <CatchmentTelemetryCharts />
        </div>

        {/* RIGHT 45% — Inputs + gauges + charts */}
        <div className="flex flex-col gap-3">
          <CascadeSimulationPanel />
          <HydroGauges />
          {/* Quick-action tiles */}
          <div className="grid grid-cols-2 gap-2">
            <QuickTile
              icon={<ShieldAlert className="h-4 w-4" />}
              label="NDRF Mobilisation"
              value={scenario === 'cloudburst' ? 'QRT 1·2·3' : 'Standby'}
              tone={scenario === 'cloudburst' ? 'rose' : 'amber'}
            />
            <QuickTile
              icon={<Radio className="h-4 w-4" />}
              label="LoRa Mesh Hops"
              value="4 / 4"
              tone="sky"
            />
            <QuickTile
              icon={<Satellite className="h-4 w-4" />}
              label="ISRO Revisit"
              value="~4 h"
              tone="emerald"
            />
            <QuickTile
              icon={<Activity className="h-4 w-4" />}
              label="EWS Heartbeat"
              value="1 Hz · live"
              tone="emerald"
            />
          </div>
        </div>
      </main>

      {/* Footer telemetry-health bar */}
      <div className="mx-auto w-full max-w-[1800px] px-3 pb-3">
        <TelemetryHealthBar />
      </div>

      {/* CAP dispatch modal (portal) */}
      <DisasterDispatchModal />
    </div>
  );
}

function StatusChip({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone?: 'green' | string;
}) {
  const toneColour =
    tone === 'green'
      ? '#22c55e'
      : typeof tone === 'string' && tone.startsWith('#')
        ? tone
        : '#94a3b8';
  return (
    <div className="flex items-center gap-1.5 rounded border border-slate-800 bg-slate-900/70 px-2 py-1">
      <span style={{ color: toneColour }}>{icon}</span>
      <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">
        {label}
      </span>
      <span className="font-mono-tactical text-[10px] font-semibold uppercase text-slate-200">
        {value}
      </span>
    </div>
  );
}

function QuickTile({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: 'rose' | 'amber' | 'sky' | 'emerald';
}) {
  const map: Record<typeof tone, string> = {
    rose: 'border-rose-700/50 bg-rose-950/40 text-rose-300',
    amber: 'border-amber-700/50 bg-amber-950/30 text-amber-300',
    sky: 'border-sky-700/50 bg-sky-950/40 text-sky-300',
    emerald: 'border-emerald-700/50 bg-emerald-950/30 text-emerald-300',
  };
  return (
    <div className={`rounded border px-3 py-2 ${map[tone]}`}>
      <div className="flex items-center gap-1.5">
        {icon}
        <span className="font-mono-tactical text-[10px] uppercase tracking-wider opacity-80">
          {label}
        </span>
      </div>
      <div className="mt-0.5 font-mono-tactical text-sm font-bold uppercase">
        {value}
      </div>
    </div>
  );
}
