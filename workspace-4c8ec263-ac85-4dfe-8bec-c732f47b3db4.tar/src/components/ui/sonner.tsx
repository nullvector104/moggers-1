"use client"

import { useTheme } from "next-themes"
import { Toaster as Sonner, ToasterProps } from "sonner"

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme()

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      position="bottom-right"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-slate-900 group-[.toaster]:text-slate-100 group-[.toaster]:border-slate-700 group-[.toaster]:rounded-md group-[.toaster]:font-mono-tactical group-[.toaster]:text-xs group-[.toaster]:shadow-[0_0_24px_rgba(56,189,248,0.15)]",
          description: "group-[.toast]:text-slate-400",
          actionButton: "group-[.toast]:bg-slate-800",
          cancelButton: "group-[.toast]:bg-slate-800",
          success: "group-[.toaster]:!border-emerald-600/60 group-[.toaster]:!bg-emerald-950/70 group-[.toaster]:!text-emerald-100",
          error: "group-[.toaster]:!border-rose-600/60 group-[.toaster]:!bg-rose-950/70 group-[.toaster]:!text-rose-100",
          warning: "group-[.toaster]:!border-amber-600/60 group-[.toaster]:!bg-amber-950/70 group-[.toaster]:!text-amber-100",
        },
      }}
      style={
        {
          "--normal-bg": "var(--popover)",
          "--normal-text": "var(--popover-foreground)",
          "--normal-border": "var(--border)",
        } as React.CSSProperties
      }
      {...props}
    />
  )
}

export { Toaster }
