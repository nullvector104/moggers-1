'use client';

import { useMemo } from 'react';
import { Crosshair, Mountain, Waves } from 'lucide-react';
import { useSimulation } from '@/lib/simulation-store';
import {
  SCENARIO_CONFIGS,
  type CatchmentNode,
  type SubCatchment,
} from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * CatchmentHazardMap
 * ------------------------------------------------------------------
 * SVG tactical map of the Upper Alaknanda–Dhauliganga catchment.
 * Shows the three sub-catchments (Upper / Mid / Lower), the river
 * cascade from Mana Pass down to Vishnuprayag, the deployed sensor
 * network, and a radar sweep that intensifies as severity escalates.
 *
 * Coordinates are projected to a 1000 × 620 viewBox.
 */

const NODES: CatchmentNode[] = [
  {
    id: 'mana-pass',
    label: 'Mana Pass AWS',
    lat: 31.083,
    lon: 79.105,
    type: 'aws',
    status: 'active',
    catchment: 'upper',
    reading: 'AWS · 3,740 m AMSL',
  },
  {
    id: 'badrinath',
    label: 'Badrinath Rain',
    lat: 30.745,
    lon: 79.495,
    type: 'rainfall',
    status: 'active',
    catchment: 'upper',
    reading: 'RG-01 · 3,133 m',
  },
  {
    id: 'dhauli-upper',
    label: 'Dhauliganga Headwaters',
    lat: 30.683,
    lon: 79.833,
    type: 'stage',
    status: 'active',
    catchment: 'upper',
    reading: 'SG-02 · 2,890 m',
  },
  {
    id: 'joshimath-aws',
    label: 'Joshimath AWS',
    lat: 30.57,
    lon: 79.566,
    type: 'aws',
    status: 'active',
    catchment: 'mid',
    reading: 'AWS · 1,875 m',
  },
  {
    id: 'joshimath-stage',
    label: 'Joshimath Gauge',
    lat: 30.555,
    lon: 79.558,
    type: 'stage',
    status: 'active',
    catchment: 'mid',
    reading: 'SG-04 · 1,750 m',
  },
  {
    id: 'helang',
    label: 'Helang Outpost',
    lat: 30.51,
    lon: 79.61,
    type: 'outpost',
    status: 'active',
    catchment: 'mid',
    reading: 'NDRF QRT-2',
  },
  {
    id: 'pandukeshwar',
    label: 'Pandukeshwar Rain',
    lat: 30.498,
    lon: 79.528,
    type: 'rainfall',
    status: 'active',
    catchment: 'mid',
    reading: 'RG-05 · 1,560 m',
  },
  {
    id: 'vishnuprayag',
    label: 'Vishnuprayag Barrage',
    lat: 30.473,
    lon: 79.567,
    type: 'barrage',
    status: 'active',
    catchment: 'lower',
    reading: 'BARRAGE · 1,372 m',
  },
  {
    id: 'auli-repeater',
    label: 'Auli Ridge Repeater',
    lat: 30.528,
    lon: 79.564,
    type: 'outpost',
    status: 'active',
    catchment: 'mid',
    reading: 'LoRa Mesh · 2,915 m',
  },
  {
    id: 'nandprayag',
    label: 'Nandprayag Downstream',
    lat: 30.336,
    lon: 79.318,
    type: 'stage',
    status: 'degraded',
    catchment: 'lower',
    reading: 'SG-09 · signal low',
  },
];

const SUBCATCHMENTS: SubCatchment[] = [
  {
    id: 'upper',
    name: 'Upper Dhauliganga',
    areaKm2: 612,
    meanSlopeDeg: 38,
    forestCoverPct: 18,
    stageM: 1.42,
    bankfullM: 4.6,
    dischargeQ: 38,
    alert: 'YELLOW',
  },
  {
    id: 'mid',
    name: 'Mid Alaknanda (Joshimath)',
    areaKm2: 482,
    meanSlopeDeg: 31,
    forestCoverPct: 42,
    stageM: 2.81,
    bankfullM: 4.6,
    dischargeQ: 156,
    alert: 'ORANGE',
  },
  {
    id: 'lower',
    name: 'Lower Alaknanda (Vishnuprayag)',
    areaKm2: 318,
    meanSlopeDeg: 24,
    forestCoverPct: 55,
    stageM: 4.7,
    bankfullM: 4.6,
    dischargeQ: 1240,
    alert: 'RED',
  },
];

/** Project WGS-84 lat/lon into the SVG viewBox. */
function project(lat: number, lon: number): { x: number; y: number } {
  const minLat = 30.2;
  const maxLat = 31.2;
  const minLon = 79.0;
  const maxLon = 80.0;
  const x = ((lon - minLon) / (maxLon - minLon)) * 1000;
  const y = (1 - (lat - minLat) / (maxLat - minLat)) * 620;
  return { x, y };
}

export function CatchmentHazardMap() {
  const scenario = useSimulation((s) => s.scenario);
  const stageH = useSimulation((s) => s.stageH);
  const dischargeQ = useSimulation((s) => s.dischargeQ);
  const cfg = SCENARIO_CONFIGS[scenario];

  const projectedNodes = useMemo(
    () => NODES.map((n) => ({ ...n, pos: project(n.lat, n.lon) })),
    [],
  );

  const surgeTarget = projectedNodes.find((n) => n.id === 'vishnuprayag');
  const surgePos = surgeTarget?.pos;

  // River path: Mana Pass → Badrinath → Dhauliganga headwaters → Joshimath → Helang → Pandukeshwar → Vishnuprayag → Nandprayag
  const riverPath = useMemo(() => {
    const ids = ['mana-pass', 'badrinath', 'dhauli-upper', 'joshimath-stage', 'helang', 'pandukeshwar', 'vishnuprayag', 'nandprayag'];
    const pts = ids
      .map((id) => projectedNodes.find((n) => n.id === id))
      .filter((n): n is CatchmentNode & { pos: { x: number; y: number } } => !!n);
    return pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.pos.x.toFixed(1)} ${p.pos.y.toFixed(1)}`).join(' ');
  }, [projectedNodes]);

  // Sub-catchment zone polygons (rough ellipses around node clusters)
  const zones = useMemo(() => {
    const make = (id: 'upper' | 'mid' | 'lower', cx: number, cy: number, rx: number, ry: number) => ({
      id,
      cx,
      cy,
      rx,
      ry,
    });
    return [
      make('upper', 540, 110, 220, 95),
      make('mid', 530, 320, 230, 110),
      make('lower', 420, 480, 200, 90),
    ];
  }, []);

  return (
    <div className="relative flex h-full flex-col rounded-md border border-slate-800 bg-slate-950/70 backdrop-blur">
      <header className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-4 py-2">
        <div className="flex items-center gap-2">
          <Crosshair className="h-4 w-4 text-sky-400" />
          <h3 className="font-mono-tactical text-xs font-semibold uppercase tracking-wider text-slate-200">
            Catchment Hazard Map · Upper Alaknanda–Dhauliganga
          </h3>
        </div>
        <div className="flex items-center gap-2 font-mono-tactical text-[10px] text-slate-400">
          <Mountain className="h-3.5 w-3.5 text-slate-500" />
          30.20–31.20°N · 79.00–80.00°E
        </div>
      </header>

      <div className="tactical-scanlines relative flex-1 overflow-hidden">
        <svg viewBox="0 0 1000 620" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid meet">
          <defs>
            <radialGradient id="mapVignette" cx="50%" cy="50%" r="65%">
              <stop offset="0%" stopColor="#0f172a" stopOpacity={0} />
              <stop offset="100%" stopColor="#020617" stopOpacity={0.85} />
            </radialGradient>
            <linearGradient id="riverFlow" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.9} />
              <stop offset="100%" stopColor="#0ea5e9" stopOpacity={0.5} />
            </linearGradient>
            {scenario === 'cloudburst' && (
              <radialGradient id="surgeHalo" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#ef4444" stopOpacity={0.55} />
                <stop offset="50%" stopColor="#dc2626" stopOpacity={0.18} />
                <stop offset="100%" stopColor="#7f1d1d" stopOpacity={0} />
              </radialGradient>
            )}
          </defs>

          {/* Background grid */}
          <g opacity="0.18">
            {Array.from({ length: 11 }).map((_, i) => (
              <line key={`v-${i}`} x1={i * 100} y1={0} x2={i * 100} y2={620} stroke="#1e3a5f" strokeWidth={0.5} />
            ))}
            {Array.from({ length: 7 }).map((_, i) => (
              <line key={`h-${i}`} x1={0} y1={i * 100} x2={1000} y2={i * 100} stroke="#1e3a5f" strokeWidth={0.5} />
            ))}
          </g>

          {/* Sub-catchment zones */}
          {zones.map((z, i) => {
            const sc = SUBCATCHMENTS[i];
            const colour =
              scenario === 'cloudburst'
                ? 'rgba(239,68,68,0.18)'
                : scenario === 'monsoon'
                  ? 'rgba(234,179,8,0.14)'
                  : 'rgba(56,189,248,0.08)';
            const stroke =
              scenario === 'cloudburst'
                ? 'rgba(239,68,68,0.55)'
                : scenario === 'monsoon'
                  ? 'rgba(234,179,8,0.45)'
                  : 'rgba(56,189,248,0.3)';
            return (
              <g key={z.id}>
                <ellipse
                  cx={z.cx}
                  cy={z.cy}
                  rx={z.rx}
                  ry={z.ry}
                  fill={colour}
                  stroke={stroke}
                  strokeWidth={1.5}
                  strokeDasharray="5 3"
                />
                <text
                  x={z.cx}
                  y={z.cy - z.ry - 6}
                  textAnchor="middle"
                  className="font-mono-tactical"
                  fontSize={11}
                  fontWeight="bold"
                  fill="#cbd5e1"
                >
                  {sc.name.toUpperCase()}
                </text>
                <text
                  x={z.cx}
                  y={z.cy - z.ry + 8}
                  textAnchor="middle"
                  className="font-mono-tactical"
                  fontSize={9}
                  fill="#64748b"
                >
                  A={sc.areaKm2} km² · slope {sc.meanSlopeDeg}°
                </text>
              </g>
            );
          })}

          {/* Radar sweep overlay (animated via CSS) */}
          {scenario !== 'dry' && (
            <g
              className="radar-sweep"
              style={{ transformBox: 'fill-box', transformOrigin: 'center' }}
              transform={`translate(${surgePos?.x ?? 500} ${surgePos?.y ?? 310})`}
            >
              <path d="M 0 0 L 160 0 A 160 160 0 0 1 113 113 Z" fill={cfg.accent} opacity={0.18} />
              <circle cx={0} cy={0} r={160} fill="none" stroke={cfg.accent} strokeWidth={0.5} strokeDasharray="2 4" opacity={0.4} />
              <circle cx={0} cy={0} r={100} fill="none" stroke={cfg.accent} strokeWidth={0.4} strokeDasharray="2 4" opacity={0.3} />
              <circle cx={0} cy={0} r={50} fill="none" stroke={cfg.accent} strokeWidth={0.4} strokeDasharray="2 4" opacity={0.25} />
            </g>
          )}

          {/* River path */}
          <path
            d={riverPath}
            fill="none"
            stroke="url(#riverFlow)"
            strokeWidth={3.5}
            strokeLinecap="round"
            strokeLinejoin="round"
            opacity={0.85}
          />
          <path
            d={riverPath}
            fill="none"
            stroke="#7dd3fc"
            strokeWidth={1}
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="2 6"
            opacity={0.6}
          >
            <animate
              attributeName="stroke-dashoffset"
              from="0"
              to="-16"
              dur="1.4s"
              repeatCount="indefinite"
            />
          </path>

          {/* Cloudburst surge halo at Vishnuprayag */}
          {scenario === 'cloudburst' && surgePos && (
            <g>
              <circle cx={surgePos.x} cy={surgePos.y} r={60} fill="url(#surgeHalo)" />
              <circle cx={surgePos.x} cy={surgePos.y} r={20} fill="none" stroke="#ef4444" strokeWidth={1.5} className="pulse-ring" />
              <circle cx={surgePos.x} cy={surgePos.y} r={10} fill="#ef4444" opacity={0.6} className="pulse-badge" />
            </g>
          )}

          {/* Sensor nodes */}
          {projectedNodes.map((n) => (
            <g key={n.id} transform={`translate(${n.pos.x} ${n.pos.y})`}>
              {/* outer ring */}
              <circle
                r={n.status === 'offline' ? 5 : 9}
                fill="none"
                stroke={nodeColor(n, scenario)}
                strokeWidth={1}
                opacity={n.status === 'degraded' ? 0.4 : 0.7}
                className={n.status === 'active' && scenario !== 'dry' ? 'status-blink' : undefined}
              />
              {/* dot */}
              <circle r={3.5} fill={nodeColor(n, scenario)} opacity={n.status === 'offline' ? 0.35 : 1} />
              {/* label */}
              <text
                x={9}
                y={-6}
                fontSize={9}
                className="font-mono-tactical"
                fill="#cbd5e1"
              >
                {n.label}
              </text>
              <text x={9} y={5} fontSize={8} className="font-mono-tactical" fill="#64748b">
                {n.reading}
              </text>
              {/* coords */}
              <text x={9} y={14} fontSize={7.5} className="font-mono-tactical" fill="#475569">
                {n.lat.toFixed(3)}°N · {n.lon.toFixed(3)}°E
              </text>
            </g>
          ))}

          {/* Map vignette */}
          <rect x={0} y={0} width={1000} height={620} fill="url(#mapVignette)" pointerEvents="none" />

          {/* Compass rose */}
          <g transform="translate(940 70)" opacity={0.75}>
            <circle r={26} fill="none" stroke="#334155" strokeWidth={0.8} />
            <path d="M 0 -22 L 4 0 L 0 4 L -4 0 Z" fill="#ef4444" />
            <path d="M 0 22 L 4 0 L 0 -4 L -4 0 Z" fill="#475569" />
            <text x={0} y={-30} textAnchor="middle" fontSize={10} className="font-mono-tactical" fill="#cbd5e1" fontWeight="bold">N</text>
            <text x={0} y={36} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#64748b">S</text>
            <text x={32} y={3} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#64748b">E</text>
            <text x={-32} y={3} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#64748b">W</text>
          </g>

          {/* Scale bar */}
          <g transform="translate(40 580)">
            <line x1={0} y1={0} x2={120} y2={0} stroke="#94a3b8" strokeWidth={2} />
            <line x1={0} y1={-4} x2={0} y2={4} stroke="#94a3b8" strokeWidth={2} />
            <line x1={60} y1={-3} x2={60} y2={3} stroke="#94a3b8" strokeWidth={1.5} />
            <line x1={120} y1={-4} x2={120} y2={4} stroke="#94a3b8" strokeWidth={2} />
            <text x={0} y={-8} fontSize={9} className="font-mono-tactical" fill="#64748b">0</text>
            <text x={60} y={-8} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#64748b">5 km</text>
            <text x={120} y={-8} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#64748b">10 km</text>
          </g>

          {/* Coordinate readout (lower-right) */}
          <g transform="translate(880 580)">
            <rect x={-130} y={-12} width={120} height={24} rx={2} fill="rgba(2,6,23,0.7)" stroke="#1e293b" />
            <text x={-70} y={4} textAnchor="middle" fontSize={9} className="font-mono-tactical" fill="#94a3b8">
              EPSG:4326 · WGS-84
            </text>
          </g>
        </svg>

        {/* Live telemetry overlay (bottom-left) */}
        <div className="absolute bottom-3 left-3 z-10 flex flex-col gap-1 rounded border border-slate-800 bg-slate-950/85 px-3 py-2 backdrop-blur">
          <div className="flex items-center gap-2">
            <Waves className="h-3.5 w-3.5 text-sky-400" />
            <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-300">
              Vishnuprayag Live Readout
            </span>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 font-mono-tactical text-[11px]">
            <span className="text-slate-500">Stage</span>
            <span className={cn('tabular-nums font-semibold', stageH > 4.6 ? 'text-rose-300' : 'text-emerald-300')}>
              {stageH.toFixed(2)} m
            </span>
            <span className="text-slate-500">Discharge</span>
            <span className="font-semibold tabular-nums text-sky-300">{dischargeQ.toFixed(0)} m³/s</span>
            <span className="text-slate-500">Bankfull</span>
            <span className="tabular-nums text-rose-300">4.60 m</span>
            <span className="text-slate-500">Δ bankfull</span>
            <span className={cn('tabular-nums font-semibold', stageH > 4.6 ? 'text-rose-300' : 'text-emerald-300')}>
              {(stageH - 4.6).toFixed(2)} m
            </span>
          </div>
        </div>

        {/* Legend (top-right) */}
        <div className="absolute right-3 top-3 z-10 flex flex-col gap-1 rounded border border-slate-800 bg-slate-950/85 px-3 py-2 backdrop-blur">
          <span className="font-mono-tactical text-[9px] uppercase tracking-wider text-slate-400">
            Legend
          </span>
          {[
            { label: 'Rainfall gauge', color: '#38bdf8' },
            { label: 'Stage gauge', color: '#22c55e' },
            { label: 'AWS', color: '#a78bfa' },
            { label: 'NDRF outpost', color: '#f59e0b' },
            { label: 'Barrage', color: '#ef4444' },
          ].map((l) => (
            <div key={l.label} className="flex items-center gap-1.5">
              <span className="inline-block h-2 w-2 rounded-full" style={{ background: l.color }} />
              <span className="font-mono-tactical text-[9px] text-slate-300">{l.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Sub-catchment summary strip */}
      <div className="grid grid-cols-3 border-t border-slate-800 bg-slate-900/40">
        {SUBCATCHMENTS.map((sc) => {
          const colour =
            scenario === 'cloudburst'
              ? '#ef4444'
              : scenario === 'monsoon' && sc.id !== 'upper'
                ? '#eab308'
                : '#22c55e';
          return (
            <div key={sc.id} className="border-r border-slate-800 px-3 py-2 last:border-r-0">
              <div className="flex items-center justify-between">
                <span className="font-mono-tactical text-[10px] font-semibold uppercase tracking-wider text-slate-200">
                  {sc.name}
                </span>
                <span
                  className="rounded border px-1.5 py-0.5 font-mono-tactical text-[9px] font-bold uppercase"
                  style={{ color: colour, borderColor: `${colour}55`, background: `${colour}11` }}
                >
                  {sc.alert}
                </span>
              </div>
              <div className="mt-1 grid grid-cols-2 gap-x-3 gap-y-0.5 font-mono-tactical text-[10px] text-slate-400">
                <span>Stage {sc.stageM.toFixed(2)} m</span>
                <span>Q {sc.dischargeQ} m³/s</span>
                <span>Slope {sc.meanSlopeDeg}°</span>
                <span>Forest {sc.forestCoverPct}%</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function nodeColor(n: CatchmentNode, scenario: keyof typeof SCENARIO_CONFIGS): string {
  if (n.status === 'offline') return '#475569';
  if (n.status === 'degraded') return '#f59e0b';
  if (scenario === 'cloudburst') {
    if (n.type === 'barrage') return '#ef4444';
    if (n.type === 'rainfall') return '#f97316';
    if (n.type === 'stage') return '#22c55e';
    if (n.type === 'aws') return '#a78bfa';
    return '#fbbf24';
  }
  if (scenario === 'monsoon') {
    if (n.type === 'rainfall') return '#38bdf8';
    if (n.type === 'stage') return '#22c55e';
    if (n.type === 'aws') return '#a78bfa';
    if (n.type === 'barrage') return '#ef4444';
    return '#fbbf24';
  }
  // dry
  if (n.type === 'rainfall') return '#38bdf8';
  if (n.type === 'stage') return '#22c55e';
  if (n.type === 'aws') return '#a78bfa';
  if (n.type === 'barrage') return '#ef4444';
  return '#94a3b8';
}
