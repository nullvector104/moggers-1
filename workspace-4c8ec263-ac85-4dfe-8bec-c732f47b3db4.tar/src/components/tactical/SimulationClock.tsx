'use client';

import { useEffect } from 'react';
import { useSimulation } from '@/lib/simulation-store';

/**
 * SimulationClock
 * ------------------------------------------------------------------
 * Headless mount-only component that advances the simulation store's
 * tick counter every second. Mounted once at the page root so the
 * surge countdown keeps ticking and the siren / strobe stay live.
 */
export function SimulationClock() {
  const advanceTick = useSimulation((s) => s.advanceTick);
  const setScenario = useSimulation((s) => s.setScenario);

  useEffect(() => {
    // Ensure the store has a populated history on first mount.
    setScenario('monsoon');
    const ivl = setInterval(advanceTick, 1000);
    return () => clearInterval(ivl);
  }, [advanceTick, setScenario]);

  return null;
}
