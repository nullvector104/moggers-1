'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import { toast as sonnerToast } from 'sonner';
import {
  ClipboardCheck,
  Copy,
  Download,
  Radio,
  Send,
  ShieldAlert,
  Terminal,
  X,
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { useSimulation } from '@/lib/simulation-store';
import { SCENARIO_CONFIGS, type BroadcastChannel, type CAPAlert } from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * DisasterDispatchModal
 * ------------------------------------------------------------------
 * NDRF operational dispatch console — issues a WMO CAP v1.2 compliant
 * emergency alert, with a multi-channel broadcast checklist and
 * transmission simulation hooks.
 *
 * The button "DISPATCH NDRF SITREP / CAP ALERT" is always visible in
 * the C2 layout; the modal mounts via the shared simulation store's
 * `dispatchOpen` flag.
 */
export function DisasterDispatchButton() {
  const setDispatchOpen = useSimulation((s) => s.setDispatchOpen);
  const scenario = useSimulation((s) => s.scenario);
  const severity = SCENARIO_CONFIGS[scenario].severity;

  return (
    <button
      type="button"
      onClick={() => setDispatchOpen(true)}
      className={cn(
        'group relative flex items-center gap-2 overflow-hidden rounded-md border px-4 py-2.5 font-mono-tactical text-xs font-bold uppercase tracking-wider transition-all',
        severity === 'RED'
          ? 'border-rose-500/70 bg-rose-950/60 text-rose-200 hover:bg-rose-900/70 pulse-badge'
          : 'border-amber-500/50 bg-amber-950/40 text-amber-200 hover:bg-amber-900/50',
      )}
    >
      <ShieldAlert className="h-4 w-4" />
      Dispatch NDRF SITREP / CAP Alert
      <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/10 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
    </button>
  );
}

export function DisasterDispatchModal() {
  const open = useSimulation((s) => s.dispatchOpen);
  const setDispatchOpen = useSimulation((s) => s.setDispatchOpen);
  const scenario = useSimulation((s) => s.scenario);
  const surgeArrivalMin = useSimulation((s) => s.surgeArrivalMin);
  const stageH = useSimulation((s) => s.stageH);
  const dischargeQ = useSimulation((s) => s.dischargeQ);
  const rainfallIntensity = useSimulation((s) => s.rainfallIntensity);
  // Alias sonnerToast → toast for ergonomic call sites below.
  const toast = sonnerToast;

  const [channels, setChannels] = useState<BroadcastChannel[]>([
    {
      id: 'smsc',
      label: 'CAP SMS-C Cell Broadcast → Local BTS Towers',
      detail: 'Joshimath, Helang, Pandukeshwar, Vishnuprayag · ~12,400 recipients',
      enabled: true,
    },
    {
      id: 'siren',
      label: 'Disaster Siren Activation',
      detail: 'Joshimath Ward 1 & 2 · Auli Tourist Zone · Helang Market',
      enabled: true,
    },
    {
      id: 'lora',
      label: 'LoRa Mesh Relay → Outpost Network (Offline Fallback)',
      detail: 'Helang Repeater → Pandukeshwar → Auli Ridge · 4 hops',
      enabled: true,
    },
    {
      id: 'iaf',
      label: 'IAF Bareilly Airbase SAR Notification',
      detail: 'Mi-17 VHR standby · 22 Sqn · EAR for casualty evacuation',
      enabled: true,
    },
    {
      id: 'ndrf',
      label: 'NDRF-08-BN (Chamoli) Auto-Mobilisation Order',
      detail: 'Search & Rescue Column · 3 Quick Response Teams',
      enabled: true,
    },
    {
      id: 'isro',
      label: 'ISRO DMSP Satellite Uplink (Cartosat-3)',
      detail: 'High-res optical + RISAT-2B SAR · 4-hour revisit',
      enabled: false,
    },
  ]);

  const [transmitting, setTransmitting] = useState(false);
  const [transmitStep, setTransmitStep] = useState(0);
  // Ref-tracked interval so rapid clicks cannot stack multiple timers
  // (the `disabled={transmitting}` flag has a render-lag during which
  // extra clicks would otherwise spawn orphan intervals). Also cleaned
  // up on unmount so closing the modal mid-relay leaves no orphans.
  const relayIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    return () => {
      if (relayIntervalRef.current) {
        clearInterval(relayIntervalRef.current);
        relayIntervalRef.current = null;
      }
    };
  }, []);

  const cap = useMemo<CAPAlert>(() => buildCAP(scenario, surgeArrivalMin, stageH, dischargeQ, rainfallIntensity), [
    scenario,
    surgeArrivalMin,
    stageH,
    dischargeQ,
    rainfallIntensity,
  ]);

  const json = useMemo(() => JSON.stringify(cap, null, 2), [cap]);
  const xml = useMemo(() => capToXML(cap), [cap]);

  const toggleChannel = (id: string) =>
    setChannels((cs) => cs.map((c) => (c.id === id ? { ...c, enabled: !c.enabled } : c)));

  const copyPayload = async (which: 'json' | 'xml') => {
    try {
      await navigator.clipboard.writeText(which === 'json' ? json : xml);
      toast.success('CAP payload copied', {
        description: `${which.toUpperCase()} payload copied to clipboard — ready for relay.`,
      });
    } catch {
      toast.error('Copy failed', {
        description: 'Clipboard API denied. Manual copy required.',
      });
    }
  };

  const downloadSitrep = () => {
    const report = buildSITREP(cap, channels);
    const blob = new Blob([report], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `NDRF-08-BN_SITREP_${cap.identifier}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('SITREP report downloaded', {
      description: `Identifier ${cap.identifier} archived locally for audit trail.`,
    });
  };

  const simulateRelay = () => {
    // Guard against double-clicks / stacking intervals — if a relay is
    // already in flight, ignore the click. This is a synchronous check
    // (no React render lag), unlike the `disabled` prop.
    if (relayIntervalRef.current) return;

    setTransmitting(true);
    setTransmitStep(0);
    const steps = [
      'Encoding CAP v1.2 payload · UTF-8',
      'Opening SATCOM uplink · GSAT-7A transponder 4B',
      'Pushing SMS-C batch (12,400 recipients)',
      'Triggering LoRa mesh beacon · Auli Ridge',
      'Notifying IAF Bareilly · 22 Sqn ops desk',
      'Acknowledgement received · relay complete',
    ];
    let i = 0;
    const ivl = setInterval(() => {
      i += 1;
      setTransmitStep(i);
      if (i >= steps.length) {
        if (relayIntervalRef.current) {
          clearInterval(relayIntervalRef.current);
          relayIntervalRef.current = null;
        }
        setTransmitting(false);
        toast.success('CAP broadcast relay complete', {
          description: 'All enabled channels acknowledged the alert within SLA.',
        });
      }
    }, 700);
    relayIntervalRef.current = ivl;
  };

  const scenarioCfg = SCENARIO_CONFIGS[scenario];
  const enabledCount = channels.filter((c) => c.enabled).length;

  return (
    <Dialog open={open} onOpenChange={setDispatchOpen}>
      <DialogContent className="max-h-[92vh] w-[min(96vw,1180px)] overflow-hidden rounded-md border-slate-700 bg-slate-950/95 p-0 backdrop-blur">
        <DialogHeader className="border-b border-slate-800 bg-slate-900/80 px-5 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded border border-rose-600/60 bg-rose-950/60">
                <ShieldAlert className="h-5 w-5 text-rose-300" />
              </div>
              <div>
                <DialogTitle className="font-mono-tactical text-sm font-bold uppercase tracking-wider text-slate-100">
                  NDRF Operational Dispatch Console
                </DialogTitle>
                <DialogDescription className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">
                  CAP v1.2 · WMO / NDMA Compliant · Sender NDRF-08-BN-CHAMOLI
                </DialogDescription>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setDispatchOpen(false)}
              className="rounded p-1 text-slate-400 hover:bg-slate-800 hover:text-slate-200"
              aria-label="Close dispatch console"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
          {/* Severity ribbon */}
          <div className="mt-2 flex items-center gap-2">
            <Badge
              variant="outline"
              className="font-mono-tactical text-[10px] uppercase"
              style={{
                color: scenarioCfg.accent,
                borderColor: `${scenarioCfg.accent}88`,
                background: `${scenarioCfg.accent}11`,
              }}
            >
              {scenarioCfg.severity} · {scenarioCfg.label}
            </Badge>
            <span className="font-mono-tactical text-[10px] text-slate-400">
              Identifier
            </span>
            <code className="rounded bg-slate-900 px-1.5 py-0.5 font-mono-tactical text-[10px] text-sky-300">
              {cap.identifier}
            </code>
            <span className="font-mono-tactical text-[10px] text-slate-400">·</span>
            <span className="font-mono-tactical text-[10px] text-slate-400">
              Sent {cap.sent}
            </span>
          </div>
        </DialogHeader>

        <div className="tactical-scroll grid max-h-[78vh] grid-cols-1 gap-4 overflow-y-auto p-5 lg:grid-cols-2">
          {/* LEFT: CAP payload */}
          <section className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="h-3.5 w-3.5 text-emerald-400" />
                <h4 className="font-mono-tactical text-[11px] font-semibold uppercase tracking-wider text-slate-200">
                  CAP Payload · JSON
                </h4>
              </div>
              <div className="flex gap-1.5">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyPayload('json')}
                  className="h-7 border-slate-700 bg-slate-900 px-2 font-mono-tactical text-[10px] uppercase text-slate-200 hover:bg-slate-800"
                >
                  <Copy className="mr-1 h-3 w-3" /> Copy JSON
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => copyPayload('xml')}
                  className="h-7 border-slate-700 bg-slate-900 px-2 font-mono-tactical text-[10px] uppercase text-slate-200 hover:bg-slate-800"
                >
                  <Copy className="mr-1 h-3 w-3" /> Copy XML
                </Button>
              </div>
            </div>
            <pre className="tactical-scroll max-h-[460px] overflow-auto rounded border border-slate-800 bg-[#020617] p-3 font-mono-tactical text-[10.5px] leading-relaxed text-emerald-300">
{json}
            </pre>

            <div className="flex items-center gap-2">
              <Radio className="h-3.5 w-3.5 text-sky-400" />
              <span className="font-mono-tactical text-[10px] uppercase text-slate-400">
                Polygon bounds (lat,lon pairs)
              </span>
            </div>
            <pre className="overflow-x-auto rounded border border-slate-800 bg-slate-900/60 p-2 font-mono-tactical text-[10px] text-slate-300">
{cap.info.area.polygon}
            </pre>
          </section>

          {/* RIGHT: broadcast checklist + actions */}
          <section className="space-y-4">
            <div>
              <div className="mb-2 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ClipboardCheck className="h-3.5 w-3.5 text-amber-400" />
                  <h4 className="font-mono-tactical text-[11px] font-semibold uppercase tracking-wider text-slate-200">
                    Multi-Channel Broadcast Checklist
                  </h4>
                </div>
                <span className="font-mono-tactical text-[10px] text-slate-400">
                  {enabledCount}/{channels.length} enabled
                </span>
              </div>
              <ul className="space-y-1.5">
                {channels.map((c) => (
                  <li
                    key={c.id}
                    className={cn(
                      'flex items-start gap-2.5 rounded border px-3 py-2 transition-colors',
                      c.enabled
                        ? 'border-emerald-700/40 bg-emerald-950/20'
                        : 'border-slate-800 bg-slate-900/40 opacity-60',
                    )}
                  >
                    <Checkbox
                      id={`ch-${c.id}`}
                      checked={c.enabled}
                      onCheckedChange={() => toggleChannel(c.id)}
                      className="mt-0.5 border-slate-600 data-[state=checked]:border-emerald-500 data-[state=checked]:bg-emerald-600"
                    />
                    <div className="flex-1">
                      <label
                        htmlFor={`ch-${c.id}`}
                        className="font-mono-tactical text-[11px] font-medium text-slate-200"
                      >
                        {c.label}
                      </label>
                      <p className="font-mono-tactical text-[10px] text-slate-400">
                        {c.detail}
                      </p>
                    </div>
                    {c.enabled && (
                      <Badge
                        variant="outline"
                        className="border-emerald-700/40 bg-emerald-950/40 font-mono-tactical text-[9px] uppercase text-emerald-300"
                      >
                        ACK
                      </Badge>
                    )}
                  </li>
                ))}
              </ul>
            </div>

            {/* Relay simulation */}
            <div className="rounded border border-slate-800 bg-slate-900/40 p-3">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-300">
                  Radio Relay Simulation
                </span>
                {transmitting && (
                  <span className="font-mono-tactical text-[10px] text-amber-300">
                    step {transmitStep}/6
                  </span>
                )}
              </div>
              {transmitting ? (
                <div className="space-y-1">
                  {[
                    'Encoding CAP v1.2 payload · UTF-8',
                    'Opening SATCOM uplink · GSAT-7A transponder 4B',
                    'Pushing SMS-C batch (12,400 recipients)',
                    'Triggering LoRa mesh beacon · Auli Ridge',
                    'Notifying IAF Bareilly · 22 Sqn ops desk',
                    'Acknowledgement received · relay complete',
                  ].map((s, idx) => (
                    <div
                      key={s}
                      className={cn(
                        'flex items-center gap-2 font-mono-tactical text-[10px]',
                        idx < transmitStep
                          ? 'text-emerald-300'
                          : idx === transmitStep
                            ? 'text-amber-300'
                            : 'text-slate-600',
                      )}
                    >
                      <span
                        className={cn(
                          'inline-block h-1.5 w-1.5 rounded-full',
                          idx < transmitStep
                            ? 'bg-emerald-400'
                            : idx === transmitStep
                              ? 'bg-amber-400 status-blink'
                              : 'bg-slate-700',
                        )}
                      />
                      {idx < transmitStep ? '✓' : '·'} {s}
                    </div>
                  ))}
                </div>
              ) : (
                <p className="font-mono-tactical text-[10px] text-slate-400">
                  Dry-run the SATCOM + LoRa relay handshake before broadcasting. The
                  simulation walks through encoding, uplink, SMS-C push, mesh beacon, IAF
                  notification and acknowledgement — no real RF emitted.
                </p>
              )}
            </div>

            {/* Action buttons */}
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={simulateRelay}
                disabled={transmitting}
                className="border-amber-600 bg-amber-700/30 font-mono-tactical text-[11px] uppercase tracking-wider text-amber-100 hover:bg-amber-700/50"
              >
                <Radio className="mr-2 h-3.5 w-3.5" />
                {transmitting ? 'Transmitting…' : 'Simulate Radio Relay'}
              </Button>
              <Button
                onClick={downloadSitrep}
                className="border-sky-600 bg-sky-700/30 font-mono-tactical text-[11px] uppercase tracking-wider text-sky-100 hover:bg-sky-700/50"
              >
                <Download className="mr-2 h-3.5 w-3.5" /> Download SITREP
              </Button>
              <Button
                onClick={() => copyPayload('json')}
                className="border-slate-600 bg-slate-800/60 font-mono-tactical text-[11px] uppercase tracking-wider text-slate-100 hover:bg-slate-700/60"
              >
                <Send className="mr-2 h-3.5 w-3.5" /> Copy Payload
              </Button>
            </div>
          </section>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/* ============================================================
   CAP payload builders (JSON + XML)
   ============================================================ */
function buildCAP(
  scenario: keyof typeof SCENARIO_CONFIGS,
  surgeArrivalMin: number,
  stageH: number,
  dischargeQ: number,
  rainfall: number,
): CAPAlert {
  const cfg = SCENARIO_CONFIGS[scenario];
  const now = new Date();
  const sent = now.toISOString();
  const onset = new Date(now.getTime() + 60_000).toISOString();
  const expires = new Date(now.getTime() + 6 * 3_600_000).toISOString();
  const id = `CAP-NDRF08BN-CHAMOLI-${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}-${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;

  const eventByScenario: Record<typeof scenario, string> = {
    dry: 'Hydrological Standdown · Alaknanda Baseflow Advisory',
    monsoon: 'Monsoon Surge Advisory · Alaknanda Catchment Watch',
    cloudburst: 'Cataclysmic Flash Flood · Imminent Overtopping at Vishnuprayag',
  };

  const urgency = scenario === 'cloudburst' ? 'Immediate' : 'Expected';
  const severity = scenario === 'cloudburst' ? 'Extreme' : scenario === 'monsoon' ? 'Severe' : 'Minor';
  const certainty = scenario === 'cloudburst' ? 'Observed' : 'Likely';

  const headline =
    scenario === 'cloudburst'
      ? `FLASH FLOOD IMMINENT · VISHNUPRAYAG · STAGE ${stageH.toFixed(2)} m · DISCHARGE ${dischargeQ} m³/s · SURGE T+${Math.ceil(surgeArrivalMin)} MIN`
      : scenario === 'monsoon'
        ? `MONSOON ADVISORY · ALAKNANDA CATCHMENT · RAINFALL ${rainfall.toFixed(1)} mm/hr`
        : `BASEFLOW ADVISORY · ALAKNANDA · STAGE ${stageH.toFixed(2)} m`;

  return {
    identifier: id,
    sender: 'NDRF-08-BN-CHAMOLI',
    sent,
    status: 'Actual',
    msgType: 'Alert',
    scope: 'Public',
    info: {
      event: eventByScenario[scenario],
      urgency,
      severity,
      certainty,
      onset,
      expires,
      headline,
      description:
        scenario === 'cloudburst'
          ? `Convective cloudburst event exceeding ${rainfall.toFixed(0)} mm/hr observed over the Upper Dhauliganga. Snowmelt-augmented runoff propagating downstream; bankfull stage at Vishnuprayag projected to be overtopped within ${Math.ceil(surgeArrivalMin)} minutes. Estimated peak discharge ${dischargeQ} m³/s. Immediate evacuation of low-lying wards (Joshimath Ward 1 & 2, Helang market, Pandukeshar riverbank) ordered.`
          : scenario === 'monsoon'
            ? `Active monsoon trough over Upper Alaknanda. Sustained rainfall ${rainfall.toFixed(1)} mm/hr; soil saturation ${cfg.antecedentMoisture * 100 | 0}%. Flash Flood Guidance threshold reduced to ${cfg.baseRainfall} mm/hr. Maintain heightened watch on Vishnuprayag gauge.`
            : `Pre-monsoon baseflow regime. Stage ${stageH.toFixed(2)} m below bankfull. Snowmelt contribution ${cfg.snowmeltContribution} m³/s. Routine advisory only — no protective action required.`,
      instruction:
        scenario === 'cloudburst'
          ? 'EVACUATE IMMEDIATELY. Move to high ground above 1,520 m AMSL. Avoid riverbeds, culverts and bridges. Do not cross flowing water. NDRF QRTs deploying to Vishnuprayag and Helang.'
          : scenario === 'monsoon'
            ? 'Standby for possible escalation. Review evacuation routes. Pre-position sandbags at Pandukeshar and Helang. Tourist movement to Auli restricted until further notice.'
            : 'Normal monitoring posture. AWS telemetry nominal. Next situational update in 30 minutes.',
      area: {
        areaDesc:
          'Upper Alaknanda-Dhauliganga Catchment, Chamoli District, Uttarakhand — Joshimath, Helang, Pandukeshwar, Vishnuprayag',
        // WGS-84 polygon: 5 vertices closing the catchment
        polygon:
          '30.7300,79.4200 30.5500,79.4700 30.4700,79.6200 30.5100,79.7900 30.7300,79.6200 30.7300,79.4200',
        geocode: 'IN-UT-CM-JSM // OSDM 052220',
      },
    },
  };
}

function capToXML(cap: CAPAlert): string {
  return `<?xml version="1.0" encoding="UTF-8"?>
<alert xmlns="urn:oasis:names:tc:emergency:CAP:1.2">
  <identifier>${cap.identifier}</identifier>
  <sender>${cap.sender}</sender>
  <sent>${cap.sent}</sent>
  <status>${cap.status}</status>
  <msgType>${cap.msgType}</msgType>
  <scope>${cap.scope}</scope>
  <info>
    <event>${cap.info.event}</event>
    <urgency>${cap.info.urgency}</urgency>
    <severity>${cap.info.severity}</severity>
    <certainty>${cap.info.certainty}</certainty>
    <onset>${cap.info.onset}</onset>
    <expires>${cap.info.expires}</expires>
    <headline>${cap.info.headline}</headline>
    <description>${cap.info.description}</description>
    <instruction>${cap.info.instruction}</instruction>
    <area>
      <areaDesc>${cap.info.area.areaDesc}</areaDesc>
      <polygon>${cap.info.area.polygon}</polygon>
      <geocode>${cap.info.area.geocode}</geocode>
    </area>
  </info>
</alert>`;
}

function buildSITREP(cap: CAPAlert, channels: BroadcastChannel[]): string {
  const lines: string[] = [];
  lines.push('================================================================');
  lines.push('  NDRF-08-BN (CHAMOLI) — SITUATION REPORT (SITREP)');
  lines.push('  Upper Alaknanda-Dhauliganga Flash Flood EWS');
  lines.push('================================================================');
  lines.push('');
  lines.push(`CAP Identifier : ${cap.identifier}`);
  lines.push(`Sender         : ${cap.sender}`);
  lines.push(`Sent (UTC)     : ${cap.sent}`);
  lines.push(`Status         : ${cap.status}  |  msgType : ${cap.msgType}  |  scope : ${cap.scope}`);
  lines.push('');
  lines.push('--- INFO BLOCK ---');
  lines.push(`Event         : ${cap.info.event}`);
  lines.push(`Urgency       : ${cap.info.urgency}`);
  lines.push(`Severity      : ${cap.info.severity}`);
  lines.push(`Certainty     : ${cap.info.certainty}`);
  lines.push(`Onset         : ${cap.info.onset}`);
  lines.push(`Expires       : ${cap.info.expires}`);
  lines.push(`Headline      : ${cap.info.headline}`);
  lines.push('');
  lines.push('Description:');
  lines.push(wrap(cap.info.description));
  lines.push('');
  lines.push('Instruction:');
  lines.push(wrap(cap.info.instruction));
  lines.push('');
  lines.push('--- AREA ---');
  lines.push(`Area Desc     : ${cap.info.area.areaDesc}`);
  lines.push(`Polygon       : ${cap.info.area.polygon}`);
  lines.push(`Geocode       : ${cap.info.area.geocode}`);
  lines.push('');
  lines.push('--- BROADCAST CHANNELS ---');
  channels.forEach((c) => {
    lines.push(`  [${c.enabled ? 'X' : ' '}] ${c.label}`);
    lines.push(`      → ${c.detail}`);
  });
  lines.push('');
  lines.push('--- ACKNOWLEDGEMENT ---');
  lines.push('Generated by: C2 Tactical Dashboard · Phase 2');
  lines.push('Audit trail : Chamoli DC ops log // NDRF 08 BN signal log');
  lines.push('================================================================');
  return lines.join('\n');
}

function wrap(s: string, w = 78): string {
  const words = s.split(' ');
  const out: string[] = [];
  let line = '';
  for (const word of words) {
    if (line.length + word.length + 1 > w) {
      out.push(line);
      line = word;
    } else {
      line = line ? `${line} ${word}` : word;
    }
  }
  if (line) out.push(line);
  return out.join('\n');
}

function pad(n: number): string {
  return n.toString().padStart(2, '0');
}
