'use client';

import { useMemo } from 'react';
import {
  CloudRain,
  CloudSnow,
  Droplets,
  Gauge as GaugeIcon,
  Layers,
  Mountain,
  Sliders,
  Thermometer,
  TrendingUp,
} from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import { useSimulation } from '@/lib/simulation-store';
import { SCENARIO_CONFIGS } from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * CascadeSimulationPanel
 * ------------------------------------------------------------------
 * Operator-facing input sliders for the hydro-meteorological drivers
 * of the cascade model, with live cascade propagation readouts that
 * summarise how the active scenario is translating through the chain.
 */
export function CascadeSimulationPanel() {
  const scenario = useSimulation((s) => s.scenario);
  const rainfall = useSimulation((s) => s.rainfallIntensity);
  const moisture = useSimulation((s) => s.antecedentMoisture);
  const snowmelt = useSimulation((s) => s.snowmeltContribution);
  const ffg = useSimulation((s) => s.ffgThreshold);
  const discharge = useSimulation((s) => s.dischargeQ);
  const stage = useSimulation((s) => s.stageH);
  const setRainfall = useSimulation((s) => s.setRainfall);
  const setMoisture = useSimulation((s) => s.setMoisture);
  const setSnowmelt = useSimulation((s) => s.setSnowmelt);
  const setScenario = useSimulation((s) => s.setScenario);

  const cfg = SCENARIO_CONFIGS[scenario];

  // Cascade propagation breakdown (rough hydrological budget in m³/s).
  const cascade = useMemo(() => {
    const rainfallRunoff = Math.max(0, rainfall - ffg) * 6.4 + rainfall * 1.2;
    const baseflow = snowmelt + 8 + moisture * 22;
    const upperQ = Math.round(baseflow + rainfallRunoff * 0.55);
    const midQ = Math.round(upperQ + rainfallRunoff * 0.32 + 14);
    const lowerQ = Math.round(midQ + rainfallRunoff * 0.18 + 6);
    const totalLoss = Math.round((upperQ + midQ + lowerQ) * 0.06);
    return {
      baseflow: Math.round(baseflow),
      rainfallRunoff: Math.round(rainfallRunoff),
      upperQ,
      midQ,
      lowerQ,
      totalLoss,
      sumQ: Math.round(baseflow + rainfallRunoff),
    };
  }, [rainfall, moisture, snowmelt, ffg]);

  return (
    <section className="rounded-md border border-slate-800 bg-slate-950/70 backdrop-blur">
      <header className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-4 py-2">
        <div className="flex items-center gap-2">
          <Sliders className="h-4 w-4 text-sky-400" />
          <h3 className="font-mono-tactical text-xs font-semibold uppercase tracking-wider text-slate-200">
            Cascade Simulation · Live Inputs
          </h3>
        </div>
        <span className="font-mono-tactical text-[10px] text-slate-400">
          3-tier scenario model · v2.4
        </span>
      </header>

      <div className="space-y-4 p-4">
        {/* Scenario selector */}
        <div>
          <Label
            icon={<Layers className="h-3 w-3 text-amber-400" />}
            text="Hydro-meteorological Scenario"
          />
          <div className="mt-2 grid grid-cols-3 gap-2">
            {(Object.keys(SCENARIO_CONFIGS) as Array<keyof typeof SCENARIO_CONFIGS>).map(
              (key) => {
                const c = SCENARIO_CONFIGS[key];
                const active = scenario === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setScenario(key)}
                    className={cn(
                      'flex flex-col items-start rounded border px-2.5 py-2 text-left transition-all',
                      active
                        ? 'bg-slate-100 text-slate-900'
                        : 'border-slate-700 bg-slate-900/60 text-slate-300 hover:border-slate-500 hover:bg-slate-800/60',
                    )}
                    style={active ? { borderColor: c.accent, background: `${c.accent}1a` } : undefined}
                  >
                    <span className="font-mono-tactical text-[10px] font-bold uppercase tracking-wider" style={{ color: active ? c.accent : undefined }}>
                      {c.shortLabel}
                    </span>
                    <span className="font-mono-tactical text-[10px] text-slate-400">
                      {c.label}
                    </span>
                  </button>
                );
              },
            )}
          </div>
        </div>

        {/* Sliders */}
        <div className="space-y-3">
          <SliderRow
            icon={<CloudRain className="h-3.5 w-3.5 text-sky-400" />}
            label="Rainfall Intensity"
            value={rainfall}
            min={0}
            max={150}
            step={0.5}
            unit="mm/hr"
            hint={rainfall > ffg ? '⚠ exceeds FFG threshold' : 'below FFG threshold'}
            tone={rainfall > ffg ? 'red' : 'default'}
            onChange={(v) => setRainfall(v[0])}
          />
          <SliderRow
            icon={<Droplets className="h-3.5 w-3.5 text-emerald-400" />}
            label="Antecedent Soil Moisture"
            value={moisture}
            min={0}
            max={1}
            step={0.01}
            unit="index"
            hint={moisture > 0.75 ? 'saturated · runoff coefficient high' : moisture > 0.4 ? 'moderate saturation' : 'dry · infiltration dominant'}
            tone="default"
            format={(v) => v.toFixed(2)}
            onChange={(v) => setMoisture(v[0])}
          />
          <SliderRow
            icon={<CloudSnow className="h-3.5 w-3.5 text-cyan-300" />}
            label="Snowmelt Contribution"
            value={snowmelt}
            min={0}
            max={80}
            step={0.5}
            unit="m³/s"
            hint="degree-day model · 0°C isotherm @ 3,800 m"
            tone="default"
            onChange={(v) => setSnowmelt(v[0])}
          />
          <SliderRow
            icon={<Thermometer className="h-3.5 w-3.5 text-rose-400" />}
            label="Flash Flood Guidance (FFG)"
            value={ffg}
            min={5}
            max={80}
            step={0.5}
            unit="mm/hr"
            hint="dynamic — derived from soil saturation"
            tone="default"
            disabled
            format={(v) => v.toFixed(1)}
            onChange={() => undefined}
          />
        </div>

        {/* Cascade propagation */}
        <div className="rounded border border-slate-800 bg-slate-900/40 p-3">
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <TrendingUp className="h-3.5 w-3.5 text-sky-400" />
              <span className="font-mono-tactical text-[10px] font-semibold uppercase tracking-wider text-slate-200">
                Cascade Propagation
              </span>
            </div>
            <span className="font-mono-tactical text-[10px] text-slate-400">
              budget · m³/s
            </span>
          </div>

          <div className="space-y-2 font-mono-tactical text-[11px]">
            <CascadeRow icon={<Mountain className="h-3 w-3 text-slate-400" />} label="Upper Dhauliganga Q" value={cascade.upperQ} />
            <CascadeConnector />
            <CascadeRow icon={<GaugeIcon className="h-3 w-3 text-slate-400" />} label="Mid Alaknanda Q (Joshimath)" value={cascade.midQ} />
            <CascadeConnector />
            <CascadeRow icon={<GaugeIcon className="h-3 w-3 text-slate-400" />} label="Lower Alaknanda Q (Vishnuprayag)" value={cascade.lowerQ} highlight={scenario === 'cloudburst'} />
            <div className="my-1.5 h-px bg-slate-800" />
            <CascadeRow icon={<Droplets className="h-3 w-3 text-slate-400" />} label="Baseflow (snowmelt + base)" value={cascade.baseflow} muted />
            <CascadeRow icon={<CloudRain className="h-3 w-3 text-slate-400" />} label="Rainfall-runoff contribution" value={cascade.rainfallRunoff} muted />
            <CascadeRow icon={<TrendingUp className="h-3 w-3 text-rose-400" />} label="Channel / infiltration loss" value={-cascade.totalLoss} muted danger />
            <div className="my-1 h-px bg-slate-700" />
            <div className="flex items-center justify-between pt-0.5">
              <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">Σ Live Q at Vishnuprayag</span>
              <span className="font-mono-tactical text-sm font-bold tabular-nums text-emerald-300">
                {discharge.toFixed(0)} m³/s
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">Live stage H</span>
              <span
                className={cn(
                  'font-mono-tactical text-sm font-bold tabular-nums',
                  stage > 4.6 ? 'text-rose-300' : 'text-sky-300',
                )}
              >
                {stage.toFixed(2)} m
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* --------------------------- Sub-components --------------------------- */

function Label({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div className="flex items-center gap-1.5">
      {icon}
      <span className="font-mono-tactical text-[10px] font-semibold uppercase tracking-wider text-slate-300">
        {text}
      </span>
    </div>
  );
}

function SliderRow({
  icon,
  label,
  value,
  min,
  max,
  step,
  unit,
  hint,
  tone,
  format,
  disabled,
  onChange,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  unit: string;
  hint: string;
  tone: 'default' | 'red';
  format?: (v: number) => string;
  disabled?: boolean;
  onChange: (v: number[]) => void;
}) {
  const display = format ? format(value) : value.toFixed(step < 1 ? 1 : 0);
  return (
    <div className="rounded border border-slate-800 bg-slate-900/40 px-3 py-2">
      <div className="mb-1 flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          {icon}
          <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-300">
            {label}
          </span>
        </div>
        <div className="flex items-baseline gap-1">
          <span
            className={cn(
              'font-mono-tactical text-sm font-bold tabular-nums',
              tone === 'red' ? 'text-rose-300' : 'text-slate-100',
            )}
          >
            {display}
          </span>
          <span className="font-mono-tactical text-[10px] text-slate-500">{unit}</span>
        </div>
      </div>
      <Slider
        value={[value]}
        min={min}
        max={max}
        step={step}
        disabled={disabled}
        onValueChange={onChange}
        className="py-1"
      />
      <p className="mt-0.5 font-mono-tactical text-[9px] text-slate-500">{hint}</p>
    </div>
  );
}

function CascadeRow({
  icon,
  label,
  value,
  highlight,
  muted,
  danger,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  highlight?: boolean;
  muted?: boolean;
  danger?: boolean;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className={cn('flex items-center gap-1.5 text-slate-300', muted && 'text-slate-500')}>
        {icon}
        {label}
      </span>
      <span
        className={cn(
          'font-mono-tactical tabular-nums',
          highlight
            ? 'font-bold text-rose-300'
            : danger
              ? 'text-rose-300'
              : muted
                ? 'text-slate-400'
                : 'font-semibold text-slate-200',
        )}
      >
        {value > 0 ? '+' : ''}
        {value} m³/s
      </span>
    </div>
  );
}

function CascadeConnector() {
  return (
    <div className="ml-1 h-3 w-px bg-gradient-to-b from-slate-600 to-transparent" />
  );
}
