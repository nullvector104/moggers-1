'use client';

import { Gauge, Layers, Radio, Waves } from 'lucide-react';
import { useSimulation } from '@/lib/simulation-store';
import { SCENARIO_CONFIGS } from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * HydroGauges
 * ------------------------------------------------------------------
 * Compact radial gauge cluster showing the live hydro-physics
 * readouts: stage H, discharge Q, FFG buffer, and lead-time.
 */
export function HydroGauges() {
  const scenario = useSimulation((s) => s.scenario);
  const stage = useSimulation((s) => s.stageH);
  const discharge = useSimulation((s) => s.dischargeQ);
  const ffg = useSimulation((s) => s.ffgThreshold);
  const rainfall = useSimulation((s) => s.rainfallIntensity);
  const surge = useSimulation((s) => s.surgeArrivalMin);
  const cfg = SCENARIO_CONFIGS[scenario];

  const stagePct = Math.min(100, (stage / 6) * 100);
  const bankfullPct = (4.6 / 6) * 100;
  const dischargePct = Math.min(100, (discharge / 1800) * 100);
  const ffgPct = Math.min(100, (ffg / 80) * 100);
  const rainfallPct = Math.min(100, (rainfall / 150) * 100);
  const ffgBuffer = Math.max(0, ffg - rainfall);
  const ffgBufferPct = Math.min(100, (ffgBuffer / 60) * 100);

  return (
    <section className="rounded-md border border-slate-800 bg-slate-950/70 backdrop-blur">
      <header className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-4 py-2">
        <div className="flex items-center gap-2">
          <Gauge className="h-4 w-4 text-emerald-400" />
          <h3 className="font-mono-tactical text-xs font-semibold uppercase tracking-wider text-slate-200">
            Hydro-Physics Gauges
          </h3>
        </div>
        <span
          className="rounded border px-1.5 py-0.5 font-mono-tactical text-[10px] font-bold uppercase"
          style={{
            color: cfg.accent,
            borderColor: `${cfg.accent}55`,
            background: `${cfg.accent}11`,
          }}
        >
          {cfg.severity}
        </span>
      </header>

      <div className="grid grid-cols-2 gap-2 p-3 lg:grid-cols-4">
        <RadialGauge
          label="Stage H"
          value={stage}
          unit="m"
          pct={stagePct}
          thresholdPct={bankfullPct}
          thresholdLabel="BANKFULL 4.6 m"
          icon={<Waves className="h-3 w-3" />}
          color={stage > 4.6 ? '#ef4444' : '#22c55e'}
          overflow={stage > 4.6}
        />
        <RadialGauge
          label="Discharge Q"
          value={discharge}
          unit="m³/s"
          pct={dischargePct}
          icon={<Radio className="h-3 w-3" />}
          color="#38bdf8"
        />
        <RadialGauge
          label="FFG Buffer"
          value={ffgBuffer}
          unit="mm/hr"
          pct={ffgBufferPct}
          thresholdPct={ffgPct}
          thresholdLabel={`FFG ${ffg.toFixed(1)} mm/hr`}
          icon={<Gauge className="h-3 w-3" />}
          color={ffgBuffer < 5 ? '#ef4444' : ffgBuffer < 20 ? '#eab308' : '#22c55e'}
        />
        <RadialGauge
          label="Rainfall Intensity"
          value={rainfall}
          unit="mm/hr"
          pct={rainfallPct}
          icon={<Layers className="h-3 w-3" />}
          color={rainfall > ffg ? '#ef4444' : '#a78bfa'}
        />
      </div>

      {/* Critical-readout strip */}
      <div className="grid grid-cols-3 border-t border-slate-800">
        <StatTile
          label="Lead-time"
          value={surge > 0 ? `${Math.ceil(surge)} min` : '—'}
          tone={surge > 0 ? 'danger' : 'default'}
        />
        <StatTile label="Bankfull Δ" value={`${(stage - 4.6).toFixed(2)} m`} tone={stage > 4.6 ? 'danger' : 'ok'} />
        <StatTile label="Q-peak T+2h" value={`${Math.round(discharge * 1.18)} m³/s`} tone="default" />
      </div>
    </section>
  );
}

function RadialGauge({
  label,
  value,
  unit,
  pct,
  thresholdPct,
  thresholdLabel,
  icon,
  color,
  overflow,
}: {
  label: string;
  value: number;
  unit: string;
  pct: number;
  thresholdPct?: number;
  thresholdLabel?: string;
  icon: React.ReactNode;
  color: string;
  overflow?: boolean;
}) {
  const r = 32;
  const c = 2 * Math.PI * r;
  const dash = (pct / 100) * c;
  return (
    <div className="relative flex flex-col items-center rounded border border-slate-800 bg-slate-900/40 p-2.5">
      <div className="mb-1 flex w-full items-center justify-between">
        <span className="flex items-center gap-1 font-mono-tactical text-[9px] uppercase tracking-wider text-slate-400">
          {icon}
          {label}
        </span>
        {overflow && (
          <span className="pulse-badge rounded border border-rose-500/60 bg-rose-950/60 px-1 font-mono-tactical text-[8px] font-bold uppercase text-rose-300">
            over
          </span>
        )}
      </div>
      <div className="relative flex h-20 w-20 items-center justify-center">
        <svg viewBox="0 0 80 80" className="absolute inset-0 h-full w-full -rotate-90">
          {/* track */}
          <circle cx={40} cy={40} r={r} fill="none" stroke="#1e293b" strokeWidth={6} />
          {/* value */}
          <circle
            cx={40}
            cy={40}
            r={r}
            fill="none"
            stroke={color}
            strokeWidth={6}
            strokeLinecap="round"
            strokeDasharray={`${dash} ${c}`}
            style={{ transition: 'stroke-dasharray 0.6s ease' }}
          />
          {/* threshold tick */}
          {thresholdPct !== undefined && (
            <line
              x1={40 + r * Math.cos((thresholdPct / 100) * 2 * Math.PI - Math.PI / 2)}
              y1={40 + r * Math.sin((thresholdPct / 100) * 2 * Math.PI - Math.PI / 2)}
              x2={40 + (r + 5) * Math.cos((thresholdPct / 100) * 2 * Math.PI - Math.PI / 2)}
              y2={40 + (r + 5) * Math.sin((thresholdPct / 100) * 2 * Math.PI - Math.PI / 2)}
              stroke="#ef4444"
              strokeWidth={2}
            />
          )}
        </svg>
        <div className="flex flex-col items-center">
          <span className="font-mono-tactical text-base font-bold tabular-nums text-slate-100">
            {value.toFixed(value < 10 ? 1 : 0)}
          </span>
          <span className="font-mono-tactical text-[9px] text-slate-500">{unit}</span>
        </div>
      </div>
      {thresholdLabel && (
        <span className="mt-1 font-mono-tactical text-[8px] uppercase tracking-wider text-rose-400/80">
          {thresholdLabel}
        </span>
      )}
    </div>
  );
}

function StatTile({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: 'default' | 'ok' | 'danger';
}) {
  return (
    <div className="border-r border-slate-800 px-3 py-2 last:border-r-0">
      <div className="font-mono-tactical text-[9px] uppercase tracking-wider text-slate-500">
        {label}
      </div>
      <div
        className={cn(
          'font-mono-tactical text-sm font-bold tabular-nums',
          tone === 'danger' && 'text-rose-300',
          tone === 'ok' && 'text-emerald-300',
          tone === 'default' && 'text-slate-200',
        )}
      >
        {value}
      </div>
    </div>
  );
}
