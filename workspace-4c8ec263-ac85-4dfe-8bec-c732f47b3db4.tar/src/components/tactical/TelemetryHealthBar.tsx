'use client';

import { useEffect, useState } from 'react';
import { Antenna, Cpu, RadioTower, Signal, Wifi } from 'lucide-react';
import type { UplinkChannel } from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * TelemetryHealthBar
 * ------------------------------------------------------------------
 * Compact telemetry uplink health strip shown at the bottom of the C2
 * dashboard. Officers use this to instantly judge whether telemetry
 * will survive a cell-tower blackout.
 *
 *  • Primary    : SATCOM (GSAT-7A)
 *  • Secondary  : VHF / LoRa Mesh Repeater Chain (Auli Ridge)
 *  • Tertiary   : Cellular 4G/5G (simulated failover)
 */
const BASE_CHANNELS: UplinkChannel[] = [
  {
    id: 'satcom',
    label: 'SATCOM · GSAT-7A',
    detail: 'Primary Ku-band uplink · NDRF HQ New Delhi',
    status: 'active',
    signalPct: 99.8,
  },
  {
    id: 'vhf',
    label: 'VHF / LoRa Mesh',
    detail: 'Auli Ridge repeater chain · 4 nodes · OFFLINE-FALLBACK CAPABLE',
    status: 'connected',
    signalPct: 87,
  },
  {
    id: 'cellular',
    label: 'Cellular 4G/5G',
    detail: 'BSNL Joshimath · Airtel Helang · SIMULATED FAILOVER',
    status: 'degraded',
    signalPct: 41,
  },
];

const STATUS_STYLES: Record<
  UplinkChannel['status'],
  { dot: string; ring: string; text: string; label: string }
> = {
  active: {
    dot: 'bg-emerald-400',
    ring: 'border-emerald-700/50',
    text: 'text-emerald-300',
    label: 'ACTIVE',
  },
  connected: {
    dot: 'bg-sky-400',
    ring: 'border-sky-700/50',
    text: 'text-sky-300',
    label: 'CONNECTED',
  },
  degraded: {
    dot: 'bg-amber-400',
    ring: 'border-amber-700/50',
    text: 'text-amber-300',
    label: 'DEGRADED',
  },
  offline: {
    dot: 'bg-rose-400',
    ring: 'border-rose-700/50',
    text: 'text-rose-300',
    label: 'OFFLINE',
  },
};

export function TelemetryHealthBar() {
  const [channels, setChannels] = useState<UplinkChannel[]>(BASE_CHANNELS);
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    // Live wall clock — null until mounted to keep SSR honest. The first
    // setNow call happens inside the interval callback (not synchronously
    // in the effect body) to avoid cascading renders.
    const tick = () => {
      setNow(new Date());
      setChannels((prev) =>
        prev.map((c) => {
          const jitter = Math.sin(Date.now() / 1000 + c.id.length) * 1.5;
          const next = Math.max(20, Math.min(100, c.signalPct + jitter));
          return { ...c, signalPct: Math.round(next * 10) / 10 };
        }),
      );
    };
    const ivl = setInterval(tick, 1000);
    return () => clearInterval(ivl);
  }, []);

  const utc = now ? now.toISOString().replace('T', ' ').slice(0, 19) + ' UTC' : '----‐‐‐ ‐‐:‐‐:‐‐';

  return (
    <footer className="mt-auto rounded-md border border-slate-800 bg-slate-950/80 backdrop-blur">
      <div className="flex flex-col gap-2 px-4 py-2 lg:flex-row lg:items-center lg:justify-between">
        {/* Left: uplink channels */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">
            Uplink
          </span>
          {channels.map((c) => {
            const s = STATUS_STYLES[c.status];
            return (
              <div
                key={c.id}
                className={cn(
                  'flex items-center gap-2 rounded border bg-slate-900/60 px-2.5 py-1',
                  s.ring,
                )}
              >
                <span className="relative flex h-2 w-2">
                  <span
                    className={cn(
                      'absolute inline-flex h-full w-full rounded-full opacity-60 status-blink',
                      s.dot,
                    )}
                  />
                  <span className={cn('relative inline-flex h-2 w-2 rounded-full', s.dot)} />
                </span>
                <div className="flex flex-col leading-tight">
                  <div className="flex items-center gap-1.5">
                    <ChannelIcon id={c.id} />
                    <span className="font-mono-tactical text-[10px] font-semibold uppercase tracking-wider text-slate-200">
                      {c.label}
                    </span>
                    <span className={cn('font-mono-tactical text-[9px] font-bold uppercase tracking-wider', s.text)}>
                      {s.label}
                    </span>
                  </div>
                  <span className="font-mono-tactical text-[9px] text-slate-500">
                    {c.detail}
                  </span>
                </div>
                <SignalMeter pct={c.signalPct} tone={c.status} />
              </div>
            );
          })}
        </div>

        {/* Right: clock + system ID */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Cpu className="h-3.5 w-3.5 text-slate-500" />
            <span className="font-mono-tactical text-[10px] text-slate-400">
              C2 Node · JSM-OPS-01
            </span>
          </div>
          <div className="flex items-center gap-1.5 rounded border border-slate-800 bg-slate-900/60 px-2 py-1">
            <Signal className="h-3 w-3 text-emerald-400 status-blink" />
            <span className="font-mono-tactical text-[10px] tabular-nums text-emerald-300">
              {utc}
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}

function ChannelIcon({ id }: { id: string }) {
  if (id === 'satcom') return <Antenna className="h-3 w-3 text-emerald-400" />;
  if (id === 'vhf') return <RadioTower className="h-3 w-3 text-sky-400" />;
  return <Wifi className="h-3 w-3 text-amber-400" />;
}

function SignalMeter({ pct, tone }: { pct: number; tone: UplinkChannel['status'] }) {
  const bars = 4;
  const filled = Math.max(1, Math.round((pct / 100) * bars));
  const color =
    tone === 'active'
      ? 'bg-emerald-400'
      : tone === 'connected'
        ? 'bg-sky-400'
        : tone === 'degraded'
          ? 'bg-amber-400'
          : 'bg-rose-400';
  return (
    <div className="ml-1 flex flex-col items-end gap-0.5">
      <div className="flex items-end gap-0.5">
        {Array.from({ length: bars }).map((_, i) => (
          <span
            key={i}
            className={cn(
              'w-1 rounded-sm',
              i < filled ? color : 'bg-slate-700',
              i === 0 && 'h-1',
              i === 1 && 'h-1.5',
              i === 2 && 'h-2',
              i === 3 && 'h-2.5',
            )}
          />
        ))}
      </div>
      <span className="font-mono-tactical text-[9px] tabular-nums text-slate-400">
        {pct.toFixed(1)}%
      </span>
    </div>
  );
}
