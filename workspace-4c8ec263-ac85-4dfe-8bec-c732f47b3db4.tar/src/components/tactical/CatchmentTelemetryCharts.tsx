'use client';

import { useMemo } from 'react';
import {
  Area,
  Bar,
  CartesianGrid,
  ComposedChart,
  Line,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Activity, Gauge, TrendingUp } from 'lucide-react';
import { useSimulation } from '@/lib/simulation-store';
import { SCENARIO_CONFIGS, type TelemetryPoint } from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * CatchmentTelemetryCharts
 * ------------------------------------------------------------------
 * Synchronised dual-axis time-series panel covering the past 6 hours
 * and a 2-hour hydrological projection.
 *
 *  • Chart A — Rainfall Intensity (bar) vs Dynamic FFG threshold (line).
 *  • Chart B — River Discharge Q (area) vs Gauge Stage H (line) with
 *              a dashed Critical Bankfull Stage reference.
 *
 * When 'Critical Cloudburst' is active, an exponential surge is drawn
 * across the projection window with a countdown marker overlaid.
 */
export function CatchmentTelemetryCharts() {
  const history = useSimulation((s) => s.history);
  const scenario = useSimulation((s) => s.scenario);
  const surgeArrivalMin = useSimulation((s) => s.surgeArrivalMin);
  const bankfull = useSimulation((s) => s.bankfullStage);

  const cfg = SCENARIO_CONFIGS[scenario];
  const isCloudburst = scenario === 'cloudburst';

  // Index in `history` where projections begin (first projected point, t=+10m).
  // Used to gate the projection-start reference line on chart A.
  const projectionStartIdx = useMemo(
    () => history.findIndex((p) => p.projected),
    [history],
  );

  const maxRainfall = useMemo(() => {
    if (history.length === 0) return 50;
    return Math.max(...history.map((p) => Math.max(p.rainfall, p.ffg))) * 1.15;
  }, [history]);

  const maxDischarge = useMemo(() => {
    if (history.length === 0) return 600;
    return Math.max(...history.map((p) => p.discharge)) * 1.2;
  }, [history]);

  const maxStage = useMemo(() => {
    if (history.length === 0) return 6;
    return Math.max(...history.map((p) => Math.max(p.stage, p.bankfull))) * 1.25;
  }, [history]);

  return (
    <div className="rounded-md border border-slate-800 bg-slate-950/70 backdrop-blur">
      <header className="flex items-center justify-between border-b border-slate-800 bg-slate-900/60 px-4 py-2">
        <div className="flex items-center gap-2">
          <Activity className="h-4 w-4 text-sky-400" />
          <h3 className="font-mono-tactical text-xs font-semibold uppercase tracking-wider text-slate-200">
            Catchment Telemetry // Hydrograph Array
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <span className="font-mono-tactical text-[10px] uppercase text-slate-400">
            Window
          </span>
          <span className="rounded border border-slate-700 px-1.5 py-0.5 font-mono-tactical text-[10px] text-slate-300">
            T-6h → T+2h
          </span>
          <span
            className="rounded border px-1.5 py-0.5 font-mono-tactical text-[10px] font-bold uppercase"
            style={{
              color: cfg.accent,
              borderColor: `${cfg.accent}55`,
              background: `${cfg.accent}11`,
            }}
          >
            {cfg.shortLabel}
          </span>
        </div>
      </header>

      <div className="space-y-3 p-3">
        {/* ==============  CHART A  ============== */}
        <ChartPanel
          title="A.  RAINFALL INTENSITY  vs  FFG THRESHOLD"
          unit="mm/hr"
          icon={<TrendingUp className="h-3.5 w-3.5 text-sky-400" />}
        >
          <ResponsiveContainer width="100%" height={170}>
            <ComposedChart
              data={history}
              syncId="tactical-hydro"
              margin={{ top: 8, right: 8, bottom: 0, left: -16 }}
            >
              <defs>
                <linearGradient id="rainfallFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#38bdf8" stopOpacity={0.9} />
                  <stop offset="100%" stopColor="#0369a1" stopOpacity={0.4} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(56,189,248,0.08)"
                vertical={false}
              />
              <XAxis
                dataKey="t"
                tick={{ fontSize: 10, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={{ stroke: '#1e293b' }}
                tickFormatter={(v: number) => `${v >= 0 ? '+' : ''}${v}m`}
              />
              <YAxis
                yAxisId="left"
                tick={{ fontSize: 10, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={{ stroke: '#1e293b' }}
                domain={[0, Math.ceil(maxRainfall)]}
                width={36}
              />
              <Tooltip
                cursor={{ fill: 'rgba(56,189,248,0.08)' }}
                content={<HydroTooltip kind="rainfall" />}
              />
              <ReferenceLine
                yAxisId="left"
                x={0}
                stroke="#fbbf24"
                strokeDasharray="4 4"
                label={{
                  value: 'T₀ NOW',
                  position: 'top',
                  fill: '#fbbf24',
                  fontSize: 9,
                  fontFamily: 'var(--font-geist-mono)',
                }}
              />
              <Bar
                yAxisId="left"
                dataKey="rainfall"
                fill="url(#rainfallFill)"
                radius={[2, 2, 0, 0]}
              />
              <Line
                yAxisId="left"
                type="monotone"
                dataKey="ffg"
                stroke="#f97316"
                strokeWidth={2}
                dot={false}
                strokeDasharray="2 4"
                isAnimationActive
              />
              {isCloudburst && projectionStartIdx >= 0 && (
                <ReferenceLine
                  yAxisId="left"
                  x={10}
                  stroke="#ef4444"
                  strokeWidth={1}
                  strokeDasharray="6 3"
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
          <Legend
            items={[
              { label: 'Rainfall', color: '#38bdf8' },
              { label: 'FFG threshold', color: '#f97316', dashed: true },
            ]}
          />
        </ChartPanel>

        {/* ==============  CHART B  ============== */}
        <ChartPanel
          title="B.  RIVER DISCHARGE Q  &  GAUGE STAGE H"
          unit="m³/s  ·  m"
          icon={<Gauge className="h-3.5 w-3.5 text-emerald-400" />}
        >
          <ResponsiveContainer width="100%" height={190}>
            <ComposedChart
              data={history}
              syncId="tactical-hydro"
              margin={{ top: 8, right: 8, bottom: 0, left: -16 }}
            >
              <defs>
                <linearGradient id="dischargeFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#22c55e" stopOpacity={0.85} />
                  <stop offset="100%" stopColor="#064e3b" stopOpacity={0.25} />
                </linearGradient>
              </defs>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="rgba(56,189,248,0.08)"
                vertical={false}
              />
              <XAxis
                dataKey="t"
                tick={{ fontSize: 10, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={{ stroke: '#1e293b' }}
                tickFormatter={(v: number) => `${v >= 0 ? '+' : ''}${v}m`}
              />
              <YAxis
                yAxisId="left"
                tick={{ fontSize: 10, fill: '#94a3b8' }}
                tickLine={false}
                axisLine={{ stroke: '#1e293b' }}
                domain={[0, Math.ceil(maxDischarge / 100) * 100]}
                width={36}
              />
              <YAxis
                yAxisId="right"
                orientation="right"
                tick={{ fontSize: 10, fill: '#a78bfa' }}
                tickLine={false}
                axisLine={{ stroke: '#1e293b' }}
                domain={[0, Math.ceil(maxStage)]}
                width={32}
              />
              <Tooltip
                cursor={{ fill: 'rgba(56,189,248,0.08)' }}
                content={<HydroTooltip kind="discharge" />}
              />
              <ReferenceLine
                yAxisId="left"
                x={0}
                stroke="#fbbf24"
                strokeDasharray="4 4"
                label={{
                  value: 'T₀ NOW',
                  position: 'top',
                  fill: '#fbbf24',
                  fontSize: 9,
                  fontFamily: 'var(--font-geist-mono)',
                }}
              />
              <Area
                yAxisId="left"
                type="monotone"
                dataKey="discharge"
                stroke="#22c55e"
                strokeWidth={2}
                fill="url(#dischargeFill)"
                isAnimationActive
              />
              <Line
                yAxisId="right"
                type="monotone"
                dataKey="stage"
                stroke="#a78bfa"
                strokeWidth={2}
                dot={false}
                isAnimationActive
              />
              <ReferenceLine
                yAxisId="right"
                y={bankfull}
                stroke="#ef4444"
                strokeDasharray="6 4"
                strokeWidth={1.5}
                label={{
                  value: `BANKFULL ${bankfull.toFixed(1)}m`,
                  position: 'insideTopRight',
                  fill: '#ef4444',
                  fontSize: 9,
                  fontFamily: 'var(--font-geist-mono)',
                }}
              />
              {isCloudburst && surgeArrivalMin > 0 && (
                <ReferenceLine
                  yAxisId="left"
                  x={Math.round(surgeArrivalMin / 10) * 10}
                  stroke="#dc2626"
                  strokeWidth={2}
                  strokeDasharray="2 2"
                  label={{
                    value: `SURGE T+${Math.round(surgeArrivalMin)}m`,
                    position: 'top',
                    fill: '#fecaca',
                    fontSize: 9,
                    fontFamily: 'var(--font-geist-mono)',
                  }}
                />
              )}
            </ComposedChart>
          </ResponsiveContainer>
          <Legend
            items={[
              { label: 'Discharge Q', color: '#22c55e' },
              { label: 'Stage H', color: '#a78bfa' },
              { label: 'Bankfull', color: '#ef4444', dashed: true },
            ]}
          />
        </ChartPanel>

        {/* Cloudburst surge lead-time marker */}
        {isCloudburst && surgeArrivalMin > 0 && (
          <div className="surge-marker flex items-center justify-between rounded border border-rose-700/60 bg-rose-950/40 px-3 py-2">
            <div className="flex items-center gap-2">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-500 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose-500" />
              </span>
              <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-rose-300">
                Exponential surge propagating downstream
              </span>
            </div>
            <div className="font-mono-tactical text-[10px] text-rose-200">
              Lead-time&nbsp;
              <span className="text-base font-bold text-rose-100">
                {Math.ceil(surgeArrivalMin)}
              </span>
              &nbsp;min · velocity ≈ 5.8 m/s
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* --------------------------- Sub-components --------------------------- */

function ChartPanel({
  title,
  unit,
  icon,
  children,
}: {
  title: string;
  unit: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded border border-slate-800 bg-slate-950/60">
      <header className="flex items-center justify-between border-b border-slate-800/80 px-3 py-1.5">
        <div className="flex items-center gap-2">
          {icon}
          <span className="font-mono-tactical text-[10px] font-semibold uppercase tracking-wider text-slate-300">
            {title}
          </span>
        </div>
        <span className="font-mono-tactical text-[10px] text-slate-500">{unit}</span>
      </header>
      <div className="px-2 pt-2">{children}</div>
    </section>
  );
}

function Legend({
  items,
}: {
  items: Array<{ label: string; color: string; dashed?: boolean }>;
}) {
  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 px-3 py-1.5">
      {items.map((item) => (
        <div key={item.label} className="flex items-center gap-1.5">
          <span
            className={cn('inline-block h-2 w-3', item.dashed && 'opacity-70')}
            style={{
              backgroundColor: item.color,
              backgroundImage: item.dashed
                ? `repeating-linear-gradient(90deg, ${item.color} 0 4px, transparent 4px 6px)`
                : undefined,
            }}
          />
          <span className="font-mono-tactical text-[10px] text-slate-400">
            {item.label}
          </span>
        </div>
      ))}
    </div>
  );
}

function HydroTooltip({
  active,
  payload,
  kind,
}: {
  active?: boolean;
  payload?: Array<{ value: number; dataKey: string; color?: string; payload?: TelemetryPoint }>;
  kind: 'rainfall' | 'discharge';
}) {
  if (!active || !payload || payload.length === 0) return null;
  const point = payload[0]?.payload;
  if (!point) return null;
  return (
    <div className="rounded border border-slate-700 bg-slate-950/95 px-3 py-2 shadow-xl">
      <div className="mb-1 font-mono-tactical text-[10px] uppercase text-slate-400">
        T {point.t >= 0 ? '+' : ''}
        {point.t}m {point.projected ? '· PROJECTION' : '· OBSERVED'}
      </div>
      {kind === 'rainfall' ? (
        <div className="space-y-0.5 font-mono-tactical text-[11px]">
          <Row label="Rainfall" value={`${point.rainfall.toFixed(1)} mm/hr`} color="#38bdf8" />
          <Row label="FFG" value={`${point.ffg.toFixed(1)} mm/hr`} color="#f97316" />
          <Row
            label="Δ FFG"
            value={`${(point.rainfall - point.ffg).toFixed(1)} mm/hr`}
            color={point.rainfall > point.ffg ? '#ef4444' : '#22c55e'}
          />
        </div>
      ) : (
        <div className="space-y-0.5 font-mono-tactical text-[11px]">
          <Row label="Discharge Q" value={`${point.discharge.toFixed(0)} m³/s`} color="#22c55e" />
          <Row label="Stage H" value={`${point.stage.toFixed(2)} m`} color="#a78bfa" />
          <Row
            label="Δ Bankfull"
            value={`${(point.stage - 4.6).toFixed(2)} m`}
            color={point.stage > 4.6 ? '#ef4444' : '#22c55e'}
          />
        </div>
      )}
    </div>
  );
}

function Row({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <span className="text-slate-400">{label}</span>
      <span style={{ color }} className="font-semibold">
        {value}
      </span>
    </div>
  );
}
