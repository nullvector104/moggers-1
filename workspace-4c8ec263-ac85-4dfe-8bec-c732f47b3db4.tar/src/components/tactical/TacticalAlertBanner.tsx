'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Radio,
  Siren,
  Timer,
  Volume2,
  VolumeX,
  Waves,
  Wind,
} from 'lucide-react';
import { useSimulation } from '@/lib/simulation-store';
import {
  SCENARIO_CONFIGS,
  SEVERITY_COLOURS,
  SEVERITY_LABELS,
  type AlertSeverity,
} from '@/lib/tactical-types';
import { cn } from '@/lib/utils';

/**
 * TacticalAlertBanner
 * ------------------------------------------------------------------
 * Operational early-warning strip rendered at the top of the C2 grid.
 *
 *  • 4-tier severity palette (GREEN / YELLOW / ORANGE / RED).
 *  • When severity = RED:
 *      → pulsating red perimeter strobe (CSS keyframe)
 *      → optional two-tone evacuation klaxon via Web Audio API
 *        (no external MP3 — synthesised in-browser)
 *      → live "SURGE ARRIVAL AT VISHNUPRAYAG: NN MIN" countdown
 */

const SEVERITY_META: Record<
  AlertSeverity,
  { bg: string; border: string; text: string; glow: string; label: string; icon: typeof Wind }
> = {
  GREEN: {
    bg: 'bg-emerald-950/40',
    border: 'border-emerald-700/50',
    text: 'text-emerald-300',
    glow: 'shadow-[0_0_18px_rgba(34,197,94,0.18)]',
    label: SEVERITY_LABELS.GREEN,
    icon: Wind,
  },
  YELLOW: {
    bg: 'bg-yellow-950/40',
    border: 'border-yellow-700/50',
    text: 'text-yellow-300',
    glow: 'shadow-[0_0_22px_rgba(234,179,8,0.22)]',
    label: SEVERITY_LABELS.YELLOW,
    icon: Waves,
  },
  ORANGE: {
    bg: 'bg-orange-950/40',
    border: 'border-orange-700/50',
    text: 'text-orange-300',
    glow: 'shadow-[0_0_24px_rgba(249,115,22,0.25)]',
    label: SEVERITY_LABELS.ORANGE,
    icon: AlertTriangle,
  },
  RED: {
    bg: 'bg-rose-950/50',
    border: 'border-rose-600/70',
    text: 'text-rose-200',
    glow: 'shadow-[0_0_30px_rgba(239,68,68,0.35)]',
    label: SEVERITY_LABELS.RED,
    icon: Siren,
  },
};

export function TacticalAlertBanner() {
  const scenario = useSimulation((s) => s.scenario);
  const audioMuted = useSimulation((s) => s.audioMuted);
  const toggleMute = useSimulation((s) => s.toggleMute);
  const surgeArrivalMin = useSimulation((s) => s.surgeArrivalMin);
  const setScenario = useSimulation((s) => s.setScenario);

  const severity = SCENARIO_CONFIGS[scenario].severity;
  const meta = SEVERITY_META[severity];
  const Icon = meta.icon;
  const isRed = severity === 'RED';

  return (
    <div
      className={cn(
        'relative overflow-hidden rounded-md border bg-slate-950/70 backdrop-blur',
        meta.border,
        meta.glow,
        isRed && 'strobe-red',
      )}
    >
      {/* Diagonal hazard ribbon when RED */}
      {isRed && (
        <div className="ribbon-flow pointer-events-none absolute inset-0 opacity-50" />
      )}

      <div className="relative flex flex-col gap-3 px-4 py-3 lg:flex-row lg:items-center lg:justify-between">
        {/* Left: severity badge + headline */}
        <div className="flex items-center gap-3">
          <div
            className={cn(
              'flex h-11 w-11 items-center justify-center rounded-md border',
              meta.border,
              meta.bg,
              isRed && 'pulse-badge',
            )}
          >
            <Icon className={cn('h-6 w-6', meta.text)} />
          </div>
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <span
                className="font-mono-tactical text-[10px] font-bold uppercase tracking-[0.2em] px-1.5 py-0.5 rounded"
                style={{
                  color: SEVERITY_COLOURS[severity],
                  background: `${SEVERITY_COLOURS[severity]}1a`,
                  border: `1px solid ${SEVERITY_COLOURS[severity]}55`,
                }}
              >
                Severity · {severity}
              </span>
              <span className="font-mono-tactical text-[10px] uppercase tracking-wider text-slate-400">
                {meta.label}
              </span>
              {isRed && (
                <span className="pulse-badge inline-flex items-center gap-1 rounded border border-rose-500/60 bg-rose-950/60 px-1.5 py-0.5 font-mono-tactical text-[9px] font-bold uppercase text-rose-200">
                  <span className="h-1.5 w-1.5 rounded-full bg-rose-400" />
                  Imminent Flash Flood
                </span>
              )}
            </div>
            <h2 className="font-mono-tactical text-sm font-semibold tracking-tight text-slate-100">
              {headlineFor(severity)}
            </h2>
            <p className="font-mono-tactical text-[11px] text-slate-400">
              {SCENARIO_CONFIGS[scenario].description}
            </p>
          </div>
        </div>

        {/* Right: surge countdown + siren toggle + scenario switcher */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Surge countdown */}
          <div
            className={cn(
              'flex items-center gap-2 rounded border px-3 py-1.5',
              isRed
                ? 'border-rose-600/70 bg-rose-950/50'
                : 'border-slate-700 bg-slate-900/70',
            )}
          >
            <Timer className={cn('h-4 w-4', isRed ? 'text-rose-300' : 'text-slate-400')} />
            <div className="flex flex-col leading-tight">
              <span className="font-mono-tactical text-[9px] uppercase tracking-wider text-slate-400">
                Surge arrival at Vishnuprayag
              </span>
              <span
                className={cn(
                  'font-mono-tactical text-base font-bold tabular-nums',
                  isRed ? 'text-rose-200' : 'text-slate-300',
                )}
              >
                {isRed && surgeArrivalMin > 0
                  ? `${Math.ceil(surgeArrivalMin).toString().padStart(2, '0')} MIN`
                  : isRed
                    ? 'ARRIVED'
                    : '— NO SURGE —'}
              </span>
            </div>
          </div>

          {/* Siren toggle */}
          <button
            type="button"
            onClick={toggleMute}
            aria-label={audioMuted ? 'Unmute evacuation siren' : 'Mute evacuation siren'}
            className={cn(
              'flex items-center gap-2 rounded border px-3 py-2 transition-colors',
              audioMuted
                ? 'border-slate-700 bg-slate-900/70 text-slate-300 hover:border-slate-500'
                : 'border-rose-500/70 bg-rose-950/60 text-rose-200 hover:bg-rose-900/60',
              isRed && !audioMuted && 'pulse-badge',
            )}
          >
            {audioMuted ? (
              <VolumeX className="h-4 w-4" />
            ) : (
              <Volume2 className="h-4 w-4" />
            )}
            <span className="font-mono-tactical text-[10px] font-bold uppercase tracking-wider">
              {audioMuted ? 'Siren Off' : 'Siren Live'}
            </span>
          </button>

          {/* Scenario switcher */}
          <div className="flex items-center gap-1 rounded border border-slate-700 bg-slate-900/70 p-1">
            <Radio className="mx-1 h-3.5 w-3.5 text-sky-400" />
            {(Object.keys(SCENARIO_CONFIGS) as Array<keyof typeof SCENARIO_CONFIGS>).map(
              (key) => {
                const c = SCENARIO_CONFIGS[key];
                const active = scenario === key;
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setScenario(key)}
                    className={cn(
                      'rounded px-2 py-1 font-mono-tactical text-[10px] font-bold uppercase tracking-wider transition-all',
                      active
                        ? 'bg-slate-100 text-slate-900'
                        : 'text-slate-400 hover:bg-slate-800 hover:text-slate-200',
                    )}
                    style={active ? { backgroundColor: c.accent } : undefined}
                  >
                    {c.shortLabel}
                  </button>
                );
              },
            )}
          </div>
        </div>
      </div>

      {/* Siren synthesiser — mounts only when needed */}
      <SirenSynth active={isRed && !audioMuted} />
    </div>
  );
}

function headlineFor(sev: AlertSeverity): string {
  switch (sev) {
    case 'GREEN':
      return 'Catchment stable · Baseflow regime nominal · Monitor snowmelt contribution';
    case 'YELLOW':
      return 'Monsoon trough active · FFG threshold dropping · Maintain watch on Upper catchment';
    case 'ORANGE':
      return 'Preparedness ordered · Stage approaching bankfull · Standby for evacuation';
    case 'RED':
      return 'CATACLYSMIC EVENT IN PROGRESS · Initiate immediate evacuation of low-lying wards';
  }
}

/* ============================================================
   SirenSynth — browser-native two-tone evacuation klaxon
   via Web Audio API. No external MP3 assets required.
   ============================================================ */
function SirenSynth({ active }: { active: boolean }) {
  const ctxRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const mountedRef = useRef(true);
  const [error, setError] = useState<string | null>(null);

  // One-shot feature detection on mount — deferred via microtask to
  // satisfy the no-setState-in-effect rule. Guarded by mountedRef so
  // the setError call is a no-op if the component unmounts first.
  useEffect(() => {
    mountedRef.current = true;
    queueMicrotask(() => {
      if (!mountedRef.current) return;
      if (typeof window === 'undefined') return;
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) {
        setError('Web Audio API unsupported on this browser');
      }
    });
    return () => {
      mountedRef.current = false;
    };
  }, []);

  const ensureContext = useCallback((): AudioContext | null => {
    if (typeof window === 'undefined') return null;
    if (!ctxRef.current) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (!AudioCtx) {
        return null;
      }
      ctxRef.current = new AudioCtx();
    }
    if (ctxRef.current.state === 'suspended') {
      void ctxRef.current.resume();
    }
    return ctxRef.current;
  }, []);

  useEffect(() => {
    if (!active) {
      // tear down
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      if (gainRef.current && ctxRef.current) {
        const now = ctxRef.current.currentTime;
        gainRef.current.gain.cancelScheduledValues(now);
        gainRef.current.gain.setValueAtTime(gainRef.current.gain.value, now);
        gainRef.current.gain.linearRampToValueAtTime(0, now + 0.15);
      }
      return;
    }

    const ctx = ensureContext();
    if (!ctx) return;

    // Master gain (ramped in to avoid click)
    const master = ctx.createGain();
    master.gain.setValueAtTime(0, ctx.currentTime);
    master.gain.linearRampToValueAtTime(0.18, ctx.currentTime + 0.25);
    master.connect(ctx.destination);
    gainRef.current = master;

    let toneHigh = true;
    const playTone = (freq: number) => {
      if (!ctxRef.current || !gainRef.current) return;
      const ac = ctxRef.current;
      const osc = ac.createOscillator();
      const oscGain = ac.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(freq, ac.currentTime);
      // slight vibrato for realism
      const lfo = ac.createOscillator();
      const lfoGain = ac.createGain();
      lfo.frequency.setValueAtTime(6, ac.currentTime);
      lfoGain.gain.setValueAtTime(8, ac.currentTime);
      lfo.connect(lfoGain);
      lfoGain.connect(osc.frequency);

      oscGain.gain.setValueAtTime(0, ac.currentTime);
      oscGain.gain.linearRampToValueAtTime(0.9, ac.currentTime + 0.04);
      oscGain.gain.linearRampToValueAtTime(0.55, ac.currentTime + 0.7);
      oscGain.gain.linearRampToValueAtTime(0, ac.currentTime + 0.9);

      osc.connect(oscGain);
      oscGain.connect(gainRef.current);
      osc.start();
      lfo.start();
      osc.stop(ac.currentTime + 0.95);
      lfo.stop(ac.currentTime + 0.95);
    };

    // Two-tone evacuation klaxon: 750 Hz / 1000 Hz alternating every 0.9s
    playTone(750);
    intervalRef.current = setInterval(() => {
      toneHigh = !toneHigh;
      playTone(toneHigh ? 1000 : 750);
    }, 900);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      intervalRef.current = null;
      if (gainRef.current && ctxRef.current) {
        const now = ctxRef.current.currentTime;
        gainRef.current.gain.cancelScheduledValues(now);
        gainRef.current.gain.linearRampToValueAtTime(0, now + 0.15);
      }
    };
  }, [active, ensureContext]);

  if (error) {
    return (
      <div className="absolute -bottom-6 right-4 font-mono-tactical text-[9px] text-rose-400">
        ⚠ {error}
      </div>
    );
  }
  return null;
}
